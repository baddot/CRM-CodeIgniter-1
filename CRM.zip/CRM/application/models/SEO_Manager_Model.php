<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SEO_Manager_Model extends CI_Model {
	public function __construct(){
		$this->load->database();
	}

    public function fetch_all(){
        $manager_id = $this->session->userdata('seoMan')->id;
        return $this->db->query("select crm_project_forward.sales_id, crm_sales_update_table.business_name, crm_sales_update_table.customer_name, crm_sales_update_table.email_id, crm_sales_update_table.domain, crm_sales_update_table.domain_name, crm_sales_update_table.domain_suggestions,crm_project_forward.time from crm_sales_update_table right join crm_project_forward on crm_sales_update_table.sales_id = crm_project_forward.sales_id left join crm_user on crm_project_forward.emp_id = crm_user.id where crm_project_forward.emp_id = '$manager_id'")->result();
    }

    public function view_profile(){
        $user_id = $this->session->userdata('seoMan')->id;

        return $this->db->query("select A.*, B.value from crm_user as A left join crm_category as B on A.department = B.cat_id where A.id = '$user_id'")->result();
    }

    public function change_password($pswrd){
        $user_id = $this->session->userdata('seoMan')->id;
        $data['password'] = $pswrd;
        
        $this->db->update('crm_user', $data, "id = '$user_id'");
    }

    public function store_comment($sales_id, $comment){
        $data['sales_id'] = $sales_id;
        $data['comment_by'] = $this->session->userdata('seoMan')->name;
        $data['comment'] = $comment;

        $this->db->insert('crm_comment',$data);
    }

    public function update_seo_keywords($sales_id, $keyword){

        $data['domain_suggestions'] = $keyword;
        $this->db->update('crm_sales_update_table', $data, "sales_id = '$sales_id'");
    }

    public function fetchTicket(){
        return $this->db->query("select crm_ticket.id, crm_ticket.ticket_id, crm_ticket.title, crm_ticket.type, crm_ticket.status, crm_ticket.description, crm_ticket.created_at, users.name, users.surname, users.email, clients.website from crm_ticket left join users on crm_ticket.from = users.uid inner join clients on users.uid = clients.uid right join crm_ticket_forward on crm_ticket.ticket_id = crm_ticket_forward.ticket_id order by crm_ticket_forward.forward_id desc")->result();
    }

    public function ticketDetails($id){
        return $this->db->query("select crm_ticket.id, crm_ticket.ticket_id, crm_ticket.title, crm_ticket.type, crm_ticket.status, crm_ticket.description, crm_ticket.created_at, users.name, users.surname, users.email, clients.website from crm_ticket left join users on crm_ticket.from = users.uid inner join clients on users.uid = clients.uid where crm_ticket.id = '$id'")->result();
    }

    public function fetchMsg($ticket_id){
        return $this->db->where('ticket_id',$ticket_id)->order_by('time', 'DESC')->get('crm_ticket_forward_reply')->result();
    }

    public function reply($ticket_id,$reply){
        $data['ticket_id'] = $ticket_id;
        $data['replied_by'] = '1';
        $data['reply_from'] = $this->session->userdata('seoMan')->name;
        $data['reply'] = $reply;

       $this->db->insert('crm_ticket_forward_reply',$data);
    }
}