<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_Model extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->database();
	}

	public function login($email, $pswrd){

 		$user = $this->db->where('email', $email)->get('crm_user')->result();
 		if(count($user) == 1){
        	$user = $user[0];
        	
        	if(password_verify($pswrd, $user->password)){
                if(($user->lead_type == 0) && ($user->status == 1)){
                    $this->session->set_userdata('user_id', $user->id);
                    $this->session->set_userdata('name', $user->name);
                    return 1;
                }
                elseif($user->lead_type === '1' && $user->status === '1'){
                	if($user->department === '16'){
//                		TODO: Sales Manager
		                unset($user->password);
		                $this->session->set_userdata('saleMan', $user);
		                redirect(base_url().'index.php/Sales_Manager_Controller/show_records');
	                }
	                elseif ($user->department === '40'){
//                		TODO: Account Manager
		                unset($user->password);
		                $this->session->set_userdata('accMan', $user);
		                redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
	                }
	                elseif ($user->department === '18'){
//                		TODO: SEO Manager
		                unset($user->password);
		                $this->session->set_userdata('seoMan', $user);
		                redirect(base_url().'index.php/SEO_Manager_Controller/show_records');
	                }
	                elseif ($user->department === '55'){
//                		TODO: SEO Manager
		                unset($user->password);
		                $this->session->set_userdata('financeMan', $user);
		                redirect(base_url().'index.php/Finance_Manager_Controller/show_records');
	                }
                }
                else
                    return 0;
            }
         	else
            	return 0;
 		}
 		return false;
	}
}