<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Finance_Manager_Controller/show_records" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class=""><a style = "color:white;" href="<?php echo base_url()?>index.php/Finance_Manager_Controller/show_records">Home</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hello, <?php echo $this->session->userdata('financeMan')->name; ?> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/finance_logout">Logout</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Finance_Manager_Controller/view_profile">View Profile</a></li>
                            <li><a href="<?php echo base_url();?>index.php/Finance_Manager_Controller/password_reset">Change Password</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <?php 
        foreach ($item as $elem) {
    ?>
    <div class="container" style="padding-top: 60px;">
        <h2 class="page-header">View Profile</h2>
        <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="text-center">
                    <img src="https://cdn2.iconfinder.com/data/icons/rcons-user/32/male-shadow-circle-512.png" width = "300px" class="avatar img-circle img-thumbnail" alt="avatar">
                    <h3><?php echo $elem->name?></h3>
                </div>
            </div>
            <div class="col-md-8 col-sm-6 col-xs-12 personal-info">
                <h3>Personal info</h3>
                <hr>
                <form class="form-horizontal" role="form">
                    <div class="form-group">
                        <label class="col-lg-3 control-label">Full name:</label>
                        <div class="col-lg-8">
                            <input class="form-control" type="text" value = "<?php echo $elem->name?>" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-3 control-label">Email:</label>
                        <div class="col-lg-8">
                            <input class="form-control" value = "<?php echo $elem->email?>" type="text" disabled>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-lg-3 control-label">Department:</label>
                        <div class="col-lg-8">
                            <div class="ui-select">
                                <select id="user_time_zone" class="form-control" disabled>
                                    <option><?php echo $elem->value?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">Company ID:</label>
                        <div class="col-md-8">
                            <input class="form-control" value = "<?php echo $elem->company_id?>" type="text" disabled>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
      <?php
        }
      ?>
</body>
<script type="text/javascript" src = "<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
        });
</script>
</html>