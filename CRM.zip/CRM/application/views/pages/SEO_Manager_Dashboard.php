<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/style_comment_box.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div id = "main_div">
    <div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a style = "background-color:#f5f5f5;" href="<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">SEO Manager Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records">View Assigned Projects</a></li>
                            <li><a href="<?php echo base_url()?>index.php/SEO_Manager_Controller/fetchTicket">View Tickets</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hello, <?php echo $this->session->userdata('seoMan')->name; ?> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/seo_logout">Logout</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/SEO_Manager_Controller/view_profile">View Profile</a></li>
                            <li><a href="<?php echo base_url();?>index.php/SEO_Manager_Controller/password_reset">Change Password</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container" style="margin-top: 100px; width:90%">
            <div class="row user-row">
                <div class="alert alert-success" role="alert" id = "succ" hidden>
                    <strong>Well done!</strong> You successfully updated the SEO Keywords..
                </div>    
                <div class="col-xs-8 col-sm-9 col-md-10 col-lg-10">
                    <div class="row col-md-12 col-md-offset-1 custyle" style = "border : 2px solid lightgrey; border-radius: 15px;">
                        <h3>Assigned Projects</h3>
                        <hr>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Project Name</th>
                                    <th>Client Name</th>
                                    <th>Email ID</th>
                                    <th>Domain</th>
                                    <th>Domain Name</th>
                                    <th>Assignment Date</th>
                                    <th colspan="2">Actions</th>
                                </tr>
                            </thead>
                            <?php
                                foreach($item as $e){
                            ?>
                            <tr>
                                <td><?php echo $e->business_name;?></td>
                                <td><?php echo $e->customer_name;?></td>
                                <td><?php echo $e->email_id;?></td>
                                <td><?php echo $e->domain;?></td>
                                
                                <?php 
                                    if($e->domain == 'New Domain'){
                                ?>
                                <td>
                                    <input type ="button" id = "sugg_btn_<?php echo $e->sales_id;?>" onclick ="show_suggestion(<?php echo $e->sales_id?>)" class='btn btn-warning' value = "Domain Suggestions">

                                    <div id="myModal2_<?php echo $e->sales_id?>" class="modal">
                                        <div class="modal-content">
                                            <span style = "float : right; cursor : pointer;" class="close2_<?php echo $e->sales_id?>">&times;</span>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <h3>New Domain Suggestions</h3>
                                                </div>
                                            </div>
                                            <hr>
                                            <form action="<?php echo base_url()?>index.php/SEO_Manager_Controller/update_seo_keywords/<?php echo $e->sales_id?>" method = "post">
                                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                            <div class="row">
                                                <textarea rows = "5" cols = "30" style = "width : " class="form-control" name="keyword" placeholder="Domain Suggestions"><?php echo $e->domain_suggestions;?></textarea>
                                            </div>
                                            <hr>
                                            <div class = "row" align="center">
                                                <input type ="submit" class='btn btn-info' value = "Update">
                                                <input type ="reset" class='btn btn-default' value = "Undo">
                                            </div>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                                <?php
                                    }else{
                                ?>
                                <td><?php echo $e->domain_name;?></td>
                                <?php
                                    }
                                ?>
                                <td><?php echo $e->time;?></td>
                                <td>
                                    <input type ="button" id = "cmnt_btn_<?php echo $e->sales_id;?>" onclick ="show_comment(<?php echo $e->sales_id?>)" class='btn btn-success' value = "Comment">

                                    <div id="myModal_<?php echo $e->sales_id?>" class="modal">
                                        <div class="modal-content">
                                            <span style = "float : right; cursor : pointer;" class="close_<?php echo $e->sales_id?>">&times;</span>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <h3>Comments</h3>
                                                </div>
                                            </div>
                                            <hr>
                                            <?php 
                                                $this->db->from('crm_comment');
                                                $query = $this->db->where('sales_id',$e->sales_id)->order_by('commented_at', 'DESC')->get();
                                                foreach ($query->result() as $row) {
                                            ?>
                                            <div class="row">
                                                <div class="col-sm-2">
                                                    <div class="thumbnail">
                                                        <img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
                                                    </div>
                                                </div>
                                                <div class="col-sm-10">
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <strong>Commented By : <?php echo $row->comment_by?></strong> <br><span class="text-muted">Date & Time : <?php echo $row->commented_at?></span>
                                                        </div>
                                                    <div class="panel-body">
                                                        <?php echo $row->comment?>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                }
                                            ?>
                                            <div class="row">
                                                <form action = "<?php echo base_url();?>index.php/SEO_Manager_Controller/store_comment/<?php echo $e->sales_id?>" method = "post">
                                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                                    <div class="col-sm-12">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                                            <textarea rows = "5" class="form-control" name="comment" placeholder="Post Your Comments"></textarea>
                                                        </div>                                   
                                                    </div>
                                                    <br>
                                                    <br>
                                                    <div class="col-sm-2">
                                                        <label></label>
                                                        <div class="input-group">
                                                            <input type="submit" class="btn btn-success green" value = "Submit">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php
                                }
                            ?>
                        </table>
                    </div>              
                </div>
            </div>
        </div>
    </div>
</body>

<script type="text/javascript" src = "<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        <?php 
            if($this->session->flashdata('seo_msg')){
        ?>
        $('#succ').show("slow");
        <?php
            }
        ?>
        setTimeout(function() { $("#succ").hide("slow"); }, 2000);
    });

    function show_comment(id){
        $(document.body).load( "<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records #main_div", function() {
            var modal = document.getElementById("myModal_"+id);
            var btn = document.getElementById("cmnt_btn_"+id);
            var span = document.getElementsByClassName("close_"+id)[0];

            modal.style.display = "block";

            span.onclick = function() {
                modal.style.display = "none";
                $(document.body).load( "<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records");
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                    $(document.body).load( "<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records");
                }
            }
        });
    }

    function show_suggestion(id){
        $(document.body).load( "<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records #main_div", function() {
            var modal = document.getElementById("myModal2_"+id);
            var btn = document.getElementById("sugg_btn_"+id);
            var span = document.getElementsByClassName("close2_"+id)[0];

            modal.style.display = "block";

            span.onclick = function() {
                modal.style.display = "none";
                $(document.body).load( "<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records");
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                    $(document.body).load( "<?php echo base_url()?>index.php/SEO_Manager_Controller/show_records");
                }
            }
        });
    }

    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
        });
</script>
</html>