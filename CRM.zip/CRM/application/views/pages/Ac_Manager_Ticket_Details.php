<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/style_chatbox.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class=""><a style = "color:white;" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Account Manager Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">View Projects</a></li>
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/fetchTicket">View Tickets</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><font color = "white">Hello, <?php echo $this->session->userdata('accMan')->name; ?></font> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/ac_logout">Logout</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/view_profile">View Profile</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/password_reset">Change Password</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container" style = "margin-top : 100px;">
        <div class="alert alert-success" role="alert" id = "succ" hidden>
                <strong>Well done!</strong> You successfully forwarded the ticket.
        </div>
        <div class="row">
            <?php
                foreach ($item as $elem) {
            ?>
            <div class="col-sm-9 col-md-7" id = "show_div">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Ticket Details</h3>
                    </div>
                    <div class="panel-body">
                        <div class="col-md-12">
                            <div class="well-block">
                                <div class="well-title">
                                    <h2></h2>
                                </div>
                                <form action = "<?php echo base_url()?>index.php/Ac_Manager_Controller/status_update/<?php echo $elem->id?>/<?php echo $elem->ticket_id?>" method="post">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="name">Ticket Title</label>
                                                <input id="name" name="name" type="text" placeholder="Ticket Title" class="form-control input-md" value = "<?php echo $elem->title;?>" disabled>
                                            </div>
                                        </div>
                                     
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="time">Ticket type</label>
                                                <select id="time" name="time" class="form-control" disabled>
                                                    <option value="<?php echo $elem->type;?>"><?php echo $elem->type;?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="time">Ticket Status</label>
                                                <select id="time" name="status" class="form-control">
                                                    <?php
                                                        if($elem->status == 'Opened'){
                                                    ?>
                                                    <option value="<?php echo $elem->status?>"><?php echo $elem->status?></option>
                                                    <option value="Answered">Answered</option>
                                                    <option value="Closed">Closed</option>
                                                    <?php
                                                        }
                                                    ?>
                                                    <?php
                                                        if($elem->status == 'Closed'){
                                                    ?>
                                                    <option value="<?php echo $elem->status?>"><?php echo $elem->status?></option>
                                                    <option value="Opened">Opened</option>
                                                    <option value="Answered">Answered</option>
                                                    <?php
                                                        }
                                                    ?>
                                                    <?php
                                                        if($elem->status == 'Answered'){
                                                    ?>
                                                    <option value="<?php echo $elem->status?>"><?php echo $elem->status?></option>
                                                    <option value="Closed">Closed</option>
                                                    <option value="Opened">Opened</option>
                                                    <?php
                                                        }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Description</label>
                                                <textarea rows = "5" placeholder="Ticket Description" class="form-control input-md" disabled><?php echo $elem->description;?></textarea>
                                            </div>
                                        </div>
                                    
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Created At</label>
                                                <input id="date" name="date" type="text" placeholder="Created At" class="form-control input-md" value = "<?php echo $elem->created_at;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Posted By</label>
                                                <input id="date" name="date" type="text" placeholder="Posted By" class="form-control input-md" value = "<?php echo $elem->name." ".$elem->surname;?>"disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Email</label>
                                                <input id="date" name="date" type="text" placeholder="Email" class="form-control input-md" value = "<?php echo $elem->email;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Website</label>
                                                <input id="date" name="date" type="text" placeholder="Website" class="form-control input-md" value = "<?php echo $elem->website;?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <button id="singlebutton" type = "submit" name="singlebutton" class="btn btn-success">Change Status</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>

                                <!-- fORWARD OPTION STARTS HERE -->
                                 <div class = "row" id = "forward_<?php echo $elem->ticket_id?>">
                                    <div class="col-sm-6">
                                        <label>Department</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                            <select name="login_cred_recv" class="form-control selectpicker" id = "dep_sel_<?php echo $elem->ticket_id?>" onchange = 'dep_sel("<?php echo $elem->ticket_id?>")'>
                                                <option value="">Select Department</option>
                                                <?php 
                                                    $query = $this->db->where('parent','1')->get('crm_category');
                                                    foreach ($query->result() as $row) {
                                                ?>
                                                <option value="<?php echo $row->value?>"><?php echo $row->value?></option>
                                                <?php
                                                    }
                                                ?>  
                                            </select>
                                        </div>                                   
                                    </div>
                                    <form action = "<?php echo base_url(); ?>index.php/Ac_Manager_Controller/forward_ticket/<?php echo $elem->id?>" method = "post">
                                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                    <div class="col-sm-6">
                                        <label>Employee</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                            <select name="emp_name" class="form-control selectpicker" id = "emp_sel_<?php echo $elem->ticket_id?>">
                                            </select>
                                        </div>                                   
                                    </div>
                                    <div class="col-sm-4">
                                        <br>
                                        <input type = "hidden" name = "ticket_id" value = "<?php echo $elem->ticket_id?>">
                                        <input id="update_btn" type="submit" class="btn btn-default btn-success" value="Forward">
                                    </div>
                                    </form>
                                </div>
                                <!-- fORWARD OPTION ENDS HERE -->
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
            <?php
            break;
                }
            ?>

            <div class="col-sm-9 col-md-5">
                <div class="portlet portlet-default">
                    <div class="portlet-heading">
                        <div class="portlet-title">
                            <h4><i class="fa fa-circle text-green"></i>   Reply to <?php echo $item[0]->name.' '.$item[0]->surname?></h4>
                        </div>
                        <div class="portlet-widgets">
                            <span class="divider"></span>
                            <a data-toggle="collapse" data-parent="#accordion" href="#chat"><i class="fa fa-chevron-down"></i></a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div id="chat" class="panel-collapse collapse in" style = "border-radius: 10px;">
                        <div class="portlet-body chat-widget" style="overflow-y: auto; width: auto; height: 370px;" id = "chatbox">
                            <?php
                                foreach ($msg as $elem1) {
                                    if($elem1->replied_by == '2'){
                            ?>
                            <div class="row"></div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="media">
                                        <a class="pull-left" href="#">
                                            <img class="media-object img-circle" src="https://image.flaticon.com/icons/png/512/49/49128.png" width = "50px" height = "50px">
                                        </a>
                                        <div class="media-body">
                                            <h4 class="media-heading"><?php echo $elem1->reply_from?>
                                                <span class="small pull-right"><?php echo date('H:i', strtotime($elem1->created_at)); ?></span><br>
                                                <span class="small pull-right"><?php echo date('d-m-Y', strtotime($elem1->created_at)); ?></span>
                                            </h4>
                                            <br>
                                            <p><?php echo $elem1->reply?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php
                                   }
                                if($elem1->replied_by == '1'){
                            ?>
                            <div class="row"></div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="media">
                                        <a class="pull-left" href="#">
                                            <img class="media-object img-circle" src="https://cdn3.iconfinder.com/data/icons/users-6/100/654853-user-men-2-512.png" width = "50px" height = "50px">
                                        </a>
                                        <div class="media-body">
                                            <h4 class="media-heading"><?php echo $elem1->ticket_from?>
                                                <span class="small pull-right"><?php echo date('H:i', strtotime($elem1->created_at)); ?></span><br>
                                                <span class="small pull-right"><?php echo date('d-m-Y', strtotime($elem1->created_at)); ?></span>
                                            </h4>
                                            <br>
                                            <p><?php echo $elem1->reply?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php
                                    }
                                }
                            ?>
                        </div>
                        <div class="portlet-footer">
                            <form role="form" action = <?php echo base_url().'index.php/Ac_Manager_Controller/reply/'.$item[0]->id.'/'.$item[0]->ticket_id.'/'.$item[0]->name.'/'.$item[0]->surname.'/'.$item[0]->status?> method = "post">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                <div class="form-group">
                                    <div class="input-group">
                                        <textarea class="form-control" rows = "4" style = "width : 97%" placeholder="Enter message..." name = "reply"></textarea>
                                        <span style = "" class="input-group-btn">
                                            <button class="btn btn-success" type="submit">Reply to Client</button>
                                        </span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-9 col-md-5">
                <div class="portlet portlet-default">
                    <div class="portlet-heading">
                        <div class="portlet-title">
                            <h4><i class="fa fa-circle text-green"></i>   Reply</h4>
                        </div>
                        <div class="portlet-widgets">
                            <span class="divider"></span>
                            <a data-toggle="collapse" data-parent="#accordion" href="#chat"><i class="fa fa-chevron-down"></i></a>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div id="chat" class="panel-collapse collapse in" style = "border-radius: 10px;">
                        <div class="portlet-body chat-widget" style="overflow-y: auto; width: auto; height: 370px;" id = "chatbox">
                            <?php

                                foreach ($msg2 as $elem1) {
                                    if($elem1->replied_by == '2'){
                            ?>
                            <div class="row"></div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="media">
                                        <a class="pull-left" href="#">
                                            <img class="media-object img-circle" src="https://image.flaticon.com/icons/png/512/49/49128.png" width = "50px" height = "50px">
                                        </a>
                                        <div class="media-body">
                                            <h4 class="media-heading"><?php echo $elem1->reply_from?>
                                                <span class="small pull-right"><?php echo date('H:i', strtotime($elem1->time)); ?></span><br>
                                                <span class="small pull-right"><?php echo date('d-m-Y', strtotime($elem1->time)); ?></span>
                                            </h4>
                                            <br>
                                            <p><?php echo $elem1->reply?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php
                                   }
                                if($elem1->replied_by == '1'){
                            ?>
                            <div class="row"></div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="media">
                                        <a class="pull-left" href="#">
                                            <img class="media-object img-circle" src="https://cdn1.iconfinder.com/data/icons/banking-4/512/manager-128.png" width = "50px" height = "50px">
                                        </a>
                                        <div class="media-body">
                                            <h4 class="media-heading"><?php echo $elem1->reply_from?>
                                                <span class="small pull-right"><?php echo date('H:i', strtotime($elem1->time)); ?></span><br>
                                                <span class="small pull-right"><?php echo date('d-m-Y', strtotime($elem1->time)); ?></span>
                                            </h4>
                                            <br>
                                            <p><?php echo $elem1->reply?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <?php
                                    }
                                }
                            ?>
                        </div>
                        <div class="portlet-footer">
                            <form role="form" action = <?php echo base_url().'index.php/Ac_Manager_Controller/reply2/'.$item[0]->id.'/'.$item[0]->ticket_id.'/'.'/'.$item[0]->status?> method = "post">
                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                <div class="form-group">
                                    <div class="input-group">
                                        <textarea class="form-control" rows = "4" style = "width : 97%" placeholder="Enter message..." name = "reply"></textarea>
                                        <span style = "" class="input-group-btn">
                                            <button class="btn btn-success" type="submit">Reply</button>
                                        </span>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function(){
        <?php 
            if($this->session->flashdata('ac_msg')){
        ?>
        $('#succ').show("slow");
        <?php
            }
        ?>
        setTimeout(function() { $("#succ").hide("slow"); }, 2000);
    });

    function dep_sel(id){
        //var csrf_test_name = $("input[name=csrf_test_name]").val();
        var dept = $("#dep_sel_"+id).val();
        $("#emp_sel_"+id).empty();
        if(dept != ''){
            $.ajax({
                type: 'GET',
                url: "<?php echo base_url();?>index.php/Ac_Manager_Controller/dep_sel/"+dept,
                dataType: 'html',
                //data: { 'csrf_test_name' : csrf_test_name,},  
                success: function(data) {
                    data = JSON.parse(data);
                    var options = '<option value="" selected>Select Employee</option>';
                    data.forEach(function(elem){
                        console.log(elem.name);
                        options = options + '<option value="'+elem.name+'">'+elem.name+'</option>';
                    });
                    document.getElementById('emp_sel_'+id).innerHTML = options;
                    //console.log(JSON.parse(data));
                    // console.log(data);
                },
            });
        }
    }

    $('ul.nav li.dropdown').hover(function() {
       $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });

    $(document).ready(function() {
        var panels = $('.user-infos');
        var panelsButton = $('.dropdown-user');
        panels.hide();

        panelsButton.click(function() {
            var dataFor = $(this).attr('data-for');
            var idFor = $(dataFor);

            var currentButton = $(this);
                idFor.slideToggle(400, function() {
                    if(idFor.is(':visible'))
                        currentButton.html('<i class="glyphicon glyphicon-chevron-up text-muted"></i>');
                    else
                        currentButton.html('<i class="glyphicon glyphicon-chevron-down text-muted"></i>');
                })
    });

    //$('[data-toggle="tooltip"]').tooltip();
    });
</script>
</html>