<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Pages_Controller';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

//TODO: Admin routes

$route['admin/login'] = 'Admin/Auth/login';
$route['admin/logout'] = 'Admin/Auth/logout';
$route['admin/dash'] = 'Admin/AdminController/dashboard';
$route['admin/editAdmin'] = 'Admin/AdminController/editProfile';
$route['admin/getUserList'] = 'Admin/AdminController/getUserList';
$route['admin/addUser'] = 'Admin/AdminController/addUser';
$route['admin/editUser'] = 'Admin/AdminController/editUser';
$route['admin/userOps/edit/(:num)'] = 'Admin/AdminController/getUserDetailsForEdit/$1';
$route['admin/userOps/del/(:num)'] = 'Admin/AdminController/delUser/$1';

//TODO: Category routes

$route['admin/getCategories'] = 'Admin/categoryController/getCategories';
$route['admin/getCategoryBasedOnValue/(:any)'] = 'Admin/categoryController/getCategoryBasedOnValue/$1';
$route['admin/getAllCategories'] = 'Admin/categoryController/getAllCategories';
$route['admin/addCategory'] = 'Admin/categoryController/addCat';
$route['admin/delCategory/(:num)'] = 'Admin/categoryController/delCat/$1';
$route['admin/editCategory'] = 'Admin/categoryController/editCat';

//TODO: Sales update routes

$route['admin/showSalesUpdate'] = 'Admin/salesController/showSales';
$route['admin/editSaleData/(:num)'] = 'Admin/salesController/editSaleData/$1';

//TODO: Complaints routes

$route['admin/showComplaints'] = 'Admin/complaintsController/getAllComplaints';
$route['admin/delComplaint/(:num)'] = 'Admin/complaintsController/deleteComplaint/$1';
$route['admin/showComplaint/(:num)'] = 'Admin/complaintsController/showComplaint/$1';
$route['admin/editComplaint/(:any)'] = 'Admin/complaintsController/editComplaint/$1';

/*
//TODO: Sales Manager routes

$route['sales/login'] = 'salesManager/Auth/login';
$route['sales/logout'] = 'salesManager/Auth/logout';

//TODO: Account Manager routes

$route['accountManager/login'] = 'accountManage/Auth/login';
$route['accountManager/logout'] = 'accountManage/Auth/logout';
*/