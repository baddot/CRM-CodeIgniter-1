<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Logout_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');
		
	}
	public function agent_logout(){
		$this->session->unset_userdata('login_email');
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('name');
		
		redirect(base_url());
	}

	public function sales_logout(){
		$this->session->unset_userdata('saleMan');

		redirect(base_url());
	}

	public function ac_logout(){
		$this->session->unset_userdata('accMan');

		redirect(base_url());
	}

	public function seo_logout(){
		$this->session->unset_userdata('seoMan');

		redirect(base_url());
	}

	public function finance_logout(){
		$this->session->unset_userdata('financeMan');

		redirect(base_url());
	}
}
