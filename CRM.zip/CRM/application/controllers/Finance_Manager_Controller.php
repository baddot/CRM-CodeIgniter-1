<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Finance_Manager_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');

		$this->load->model('Finance_Manager_Model');		
	}
	
	public function show_records(){
		if(!$this->authVerifier->verifyFinanceManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Finance_Manager_Model->fetch();
		foreach ($data['item'] as $value) {
			@$value->agentName = $this->Finance_Manager_Model->fetchAgent($value->user_id)[0]->name;
		}
		$this->load->view('pages/Finance_Manager_Dashboard',$data);
	}

	public function view_profile(){
    	if(!$this->authVerifier->verifyFinanceManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Finance_Manager_Model->view_profile();
		
		$this->load->view('pages/Finance_Manager_Profile', $data);
    }

    public function password_reset(){		//For loading the view
    	if(!$this->authVerifier->verifyFinanceManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$this->load->view('pages/Finance_Manager_Password_Reset');
    }

    public function change_password(){		//For changing the password
    	if(!$this->authVerifier->verifyFinanceManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$new_password = $this->input->post('password_confirmation');
		
		$len = strlen($new_password);
		
		if($len>=6){
			$encrypt_password = password_hash($new_password, PASSWORD_BCRYPT);
			$this->Finance_Manager_Model->change_password($encrypt_password);

			$this->session->set_flashdata('fin_msg',' ');
			redirect(base_url().'index.php/Finance_Manager_Controller/password_reset');
		}
    }

    public function payment($sales_id){
		$this->Finance_Manager_Model->payment($sales_id);
		redirect(base_url().'index.php/Finance_Manager_Controller/show_records');
	}
}
