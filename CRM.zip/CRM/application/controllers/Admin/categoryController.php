<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 04-Jul-17
 * Time: 4:49 PM
 */
class categoryController extends CI_Controller
{

	function getCategories(){
		if($this->authVerifier->verifyAdmin()){
			$categories = $this->db->get('crm_category')->result();
			if(count($categories))
			{
				$data = array();
				$index = 0;
				foreach ($categories as $category){
					$childIndex = 0;
					foreach ($categories as $categoryChild){
						if($categoryChild->parent === $category->cat_id){
							$data[$index]['child'][$childIndex] = $categoryChild;
							$childIndex++;
						}
					}
					if(isset($data[$index]['child']))
					{
						$data[$index]['parent'] = $category;
						$index++;
					}
					else{
						if($category->parent === '0')
						{
							$data[$index]['parent'] = $category;
							$index++;
						}
					}
				}
				echo json_encode($data);
			}
			else
				echo json_encode(array('code' => 404, 'msg' => 'No categories found'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as an admin'));
	}

	function getCategoryBasedOnValue($value){
		if($this->authVerifier->verifyAdmin()){
			$data = array();
			$checkCat = $this->db->where('value', $value)->get('crm_category')->result();
			if(count($checkCat)){
				$checkCat = $checkCat[0];
				$data['parent'] = $checkCat;
				$child = $this->db->where('parent', $checkCat->cat_id)->get('crm_category')->result();
				if(count($child))
					$data['child'] = $child;
				$getManagers = $this->db->where('lead_type', '1')->get('crm_user')->result();
				if(count($getManagers))
				{
					foreach ($getManagers as $manager)
						unset($manager->password);
					$data['managers'] = $getManagers;
				}
				echo json_encode($data);
			}
			else{
				$checkCat = $this->db->where('cat_id', $value)->get('crm_category')->result();
				if(count($checkCat)){
					$checkCat = $checkCat[0];
					$data['parent'] = $checkCat;
					$child = $this->db->where('parent', $checkCat->cat_id)->get('crm_category')->result();
					if(count($child))
						$data['child'] = $child;
					$getManagers = $this->db->where('lead_type', '1')->get('crm_user')->result();
					if(count($getManagers))
					{
						foreach ($getManagers as $manager)
							unset($manager->password);
						$data['managers'] = $getManagers;
					}
					echo json_encode($data);
				}
				else
					echo json_encode(array('code' => 404, 'msg' => 'Unable to find category'));
			}
		}
		else{
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
		}
	}

	function getAllCategories(){
		if($this->authVerifier->verifyAdmin()){
			$categories = $this->db->get('crm_category')->result();
			if(count($categories))
				echo json_encode($categories);
			else
				echo json_encode(array('code' => 404, 'msg' => 'No categories found!'));
		}
		else{
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
		}
	}

	function addCat(){
		if($this->authVerifier->verifyAdmin())
		{
			$parent = $this->input->get('parent');
			$newCatName = $this->input->get('newCatName');
			if($parent){
				$checkParent = $this->db->where('cat_id', $parent)->get('crm_category')->result();
				if(count($checkParent)){
					$NewCatAlreadyExists = $this->db->where(array('value' => $newCatName, 'parent' => $parent))->get('crm_category')->result();
					if(count($NewCatAlreadyExists))
					{
						echo json_encode(array('code' => 403, 'msg' => 'Category already exists'));
					}
					else
					{
						$data = array(
							'parent' => $parent,
							'value' => $newCatName
						);
						$newCat = $this->db->insert('crm_category', $data);
						if($newCat){
							echo json_encode(array('code' => 200, 'msg' => 'New child category successfully added'));
						}
						else
							echo json_encode(array('code' => 500, 'msg' => 'Internal server error'));
					}
				}
				else
					echo json_encode(array('code' => 404, 'msg' => 'Parent category not found'));
			}
			else{
				unset($parent);
				$NewCatAlreadyExists = $this->db->where('value', $newCatName)->get('crm_category')->result();
				if(count($NewCatAlreadyExists))
					echo json_encode(array('code' => 403, 'msg' => 'Category already exists'));
				else{
					$data = array(
						'parent' => 0,
						'value' => $newCatName
					);
					$newCat = $this->db->insert('crm_category', $data);
					if($newCat){
						echo json_encode(array('code' => 200, 'msg' => 'Parent category successfully added'));
					}
					else
						echo json_encode(array('code' => 500, 'msg' => 'Internal server error'));
				}
			}
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin.'));
	}

	function delCat($id){
		if($this->authVerifier->verifyAdmin()){
			$catExists = $this->db->where('cat_id', $id)->get('crm_category')->result();
			if(count($catExists)){
				$catExists = $catExists[0];
				if($catExists->parent === '0'){
					$removeChildren = $this->db->where('parent', $id)->delete('crm_category');
					if($removeChildren){
						$removeParent = $this->db->where('cat_id', $id)->delete('crm_category');
						if($removeParent)
							echo json_encode(array('code' => 200, 'msg' => 'Parent category deleted along with children'));
						else
							echo json_encode(array('code' => 500, 'msg' => 'Internal error, unable to delete parent. Children deleted'));
					}
					else
						echo json_encode(array('code' => 500, 'msg' => 'Internal error. Unable to delete child categories for the selected parent category'));
				}
				else{
					$removeChild = $this->db->where('cat_id', $id)->delete('crm_category');
					if($removeChild)
						echo json_encode(array('code' => 200, 'msg' => 'Child category deleted'));
					else
						echo json_encode(array('code' => 500, 'msg' => 'Internal error. Unable to delete child category'));
				}
			}
			else
				echo json_encode(array('code' => 404, 'msg' => 'Category not found'));
		}
		else{
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
		}
	}

	function editCat(){
		if($this->authVerifier->verifyAdmin()){
			$id = $this->input->get('id');
			$newValue = $this->input->get('value');
			$modifyCat = $this->db->where('cat_id', $id)->update('crm_category', array('value' => $newValue));
			if($modifyCat)
				echo json_encode(array('code' => 200, 'msg' => 'Category value successfully updated'));
			else
				echo json_encode(array('code' => 500, 'msg' => 'Internal error'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
	}

}