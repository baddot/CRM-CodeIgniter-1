<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');

		$this->load->library('session');
		
		$this->load->model('Form_Model');		
		$this->load->model('User_Model');		
	}
	public function index()
	{	
		/*if($this->authVerifier->verifySalesManager())
			redirect(base_url().'index.php/Sales_Manager_Controller/show_records');
		if($this->authVerifier->verifyAccountsManager())
			redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
		if($this->authVerifier->verifySEOManager())
			redirect(base_url().'index.php/SEO_Manager_Controller/show_records');
		if($this->authVerifier->verifyFinanceManager())
			redirect(base_url().'index.php/Finance_Manager_Controller/show_records');*/
		if($this->session->userdata('login_email')){
			redirect(base_url().'index.php/Form_Controller');
		}
		$this->load->view('pages/login.php');
	}

	public function fetchAll($var = 0){
		if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php');
		}
		
		$user_id = $this->session->userdata('user_id');
		$data['item'] = $this->Form_Model->fetchAll($user_id);
		$this->load->view('pages/fetch_forms',$data);
	}

	public function store_comment($sales_id){
    	if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php');
		}

    	$comment = $this->input->post('comment');

    	if($comment != '')
    		$this->Form_Model->store_comment($sales_id, $comment);

    	redirect(base_url().'index.php/Pages_Controller/fetchAll');
    }

    public function view_profile(){
    	if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php');
		}

		$data['item'] = $this->User_Model->view_profile();
		
		$this->load->view('pages/User_Profile', $data);
    }

    public function password_reset(){		//For Loading the view
    	if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php');
		}
		$this->load->view('pages/User_Password_Reset');
    }

    public function change_password(){		//For changing the password
    	if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php');
		}

		$new_password = $this->input->post('password_confirmation');
		
		$len = strlen($new_password);
		
		if($len>=6){
			$encrypt_password = password_hash($new_password, PASSWORD_BCRYPT);
			$this->User_Model->change_password($encrypt_password);

			$this->session->set_flashdata('msg',' ');
			redirect(base_url().'index.php/Pages_Controller/password_reset');
		}
    }
}
