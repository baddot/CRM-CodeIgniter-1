<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_Manager_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');

		$this->load->model('Sales_Manager_Model');		
	}
	public function show_records(){
		if(!$this->authVerifier->verifySalesManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Sales_Manager_Model->fetch();;
		foreach ($data['item'] as $value) {
			@$value->agentName = $this->Sales_Manager_Model->fetchAgent($value->user_id)[0]->name;
		}
		$this->load->view('pages/Sales_Manager_Dashboard',$data);
	}

	public function approve($sales_id){
		$this->Sales_Manager_Model->approve($sales_id);
		redirect(base_url().'index.php/Sales_Manager_Controller/show_records');
	}

	public function store_comment($sales_id){
    	if(!$this->authVerifier->verifySalesManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
    	$comment = $this->input->post('comment');

    	if($comment != '')
    		$this->Sales_Manager_Model->store_comment($sales_id, $comment);

    	redirect(base_url().'index.php/Sales_Manager_Controller/show_records');
    }

    public function view_profile(){
    	if(!$this->authVerifier->verifySalesManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Sales_Manager_Model->view_profile();
		
		$this->load->view('pages/Sales_Manager_Profile', $data);
    }

    public function password_reset(){		//For loading the view
    	if(!$this->authVerifier->verifySalesManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$this->load->view('pages/Sales_Manager_Password_Reset');
    }

    public function change_password(){		//For changing the password
    	if(!$this->authVerifier->verifySalesManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$new_password = $this->input->post('password_confirmation');
		
		$len = strlen($new_password);
		
		if($len>=6){
			$encrypt_password = password_hash($new_password, PASSWORD_BCRYPT);
			$this->Sales_Manager_Model->change_password($encrypt_password);

			$this->session->set_flashdata('sales_msg',' ');
			redirect(base_url().'index.php/Sales_Manager_Controller/password_reset');
		}
    }
}
