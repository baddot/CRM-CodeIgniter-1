<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ac_Manager_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');

		$this->load->model('Ac_Manager_Model');	

		$config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'mail.nextweb.com.au',
                'smtp_port' => 25,
                'smtp_user' => 'souravsarkar@nextweb.com.au', 
                'smtp_pass' => 'sourav1995',
                'mailtype' => 'html',
        );	

        $this->load->library('email', $config);
	}
	

	public function show_records(){
		if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Ac_Manager_Model->fetch();

		foreach ($data['item'] as $value) {
			@$value->agentName = $this->Ac_Manager_Model->fetchAgent($value->user_id)[0]->name;
		}
		$this->load->view('pages/Ac_Manager_Dashboard',$data);
	}

	public function approve($sales_id){
		$this->Ac_Manager_Model->approve($sales_id);
		redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
	}

	public function fetchTicket(){
		if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$data['item'] = $this->Ac_Manager_Model->fetchTicket();
		
		$this->load->view('pages/Ac_Manager_Tickets',$data);
	}

	public function ticketDetails($id){
		if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$data['item'] = $this->Ac_Manager_Model->ticketDetails($id);
		$data['msg'] = $this->Ac_Manager_Model->fetchMsg($data['item'][0]->ticket_id);
		$data['msg2'] = $this->Ac_Manager_Model->fetchMsg2($data['item'][0]->ticket_id);

		$this->load->view('pages/Ac_Manager_Ticket_Details',$data);
	}

	public function reply($id,$ticket_id,$f_name,$l_name){
		if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$reply = $this->input->post('reply');
		if($reply != '')
			$this->Ac_Manager_Model->reply($ticket_id, $f_name, $l_name, $reply);

		redirect(base_url().'index.php/Ac_Manager_Controller/ticketDetails/'.$id);
    }

    public function reply2($id,$ticket_id){
		if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$reply = $this->input->post('reply');
		if($reply != '')
			$this->Ac_Manager_Model->reply2($ticket_id, $reply);

		redirect(base_url().'index.php/Ac_Manager_Controller/ticketDetails/'.$id);
    }

    public function status_update($id, $ticket_id){
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
    	$status = $this->input->post('status');
    	$this->Ac_Manager_Model->status_update($ticket_id, $status);
    	redirect(base_url().'index.php/Ac_Manager_Controller/ticketDetails/'.$id);
    }

    public function store_comment($sales_id){
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
    	$comment = $this->input->post('comment');

    	if($comment != '')
    		$this->Ac_Manager_Model->store_comment($sales_id, $comment);
    	redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
    }

    public function dep_sel($dept){
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Ac_Manager_Model->dep_sel($dept);
		echo json_encode($data['item']);
    }

    public function forward_ticket($id){
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
    	if($this->input->post()){
    		$ticket_id = $this->input->post('ticket_id');
    		$emp_name = $this->input->post('emp_name');
    		if($emp_name != '')
    			$this->Ac_Manager_Model->forward_ticket($ticket_id, $emp_name);
    		$this->session->set_flashdata('ac_msg',' ');
    		redirect(base_url().'index.php/Ac_Manager_Controller/ticketDetails/'.$id);
    	}
    }

    public function forward_project(){
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

    	if($this->input->post()){
    		$sales_id = $this->input->post('sales_id');
    		$emp_name = $this->input->post('emp_name');
    		if($emp_name != '')
    			$this->Ac_Manager_Model->forward_project($sales_id, $emp_name);

    		$this->session->set_flashdata('ac_msg',' ');
    		redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
    	}
    }

    public function view_profile(){
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->Ac_Manager_Model->view_profile();
		
		$this->load->view('pages/Ac_Manager_Profile', $data);
    }

    public function password_reset(){		//For loading the view
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$this->load->view('pages/Ac_Manager_Password_Reset');
    }

    public function change_password(){		//For changing the password
    	if(!$this->authVerifier->verifyAccountsManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$new_password = $this->input->post('password_confirmation');
		
		$len = strlen($new_password);
		
		if($len>=6){
			$encrypt_password = password_hash($new_password, PASSWORD_BCRYPT);
			$this->Ac_Manager_Model->change_password($encrypt_password);

			$this->session->set_flashdata('ac_msg',' ');
			redirect(base_url().'index.php/Ac_Manager_Controller/password_reset');
		}
    }

    public function send_invoice($sales_id){
    	$email = $this->input->post('mail_add');
    	$cmnt = $this->input->post('send_comment');

    	if($email != ''){
    		$sub = "This is your invoice";
    		$this->email->from('souravsarkar@nextweb.com.au', 'Sourav Sarkar');
			$this->email->to($email);
			$this->email->subject('Invoice');
			$this->email->message('<b>Subject : </b>'.$sub.'<br><b>Comment : </b>'.$cmnt);

			if($this->email->send()){
				$this->Ac_Manager_Model->send_invoice($sales_id);

				$this->session->set_flashdata('succ_msg',' ');
    			redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
			}
			else{
				$this->session->set_flashdata('fail_msg',' ');
    			redirect(base_url().'index.php/Ac_Manager_Controller/show_records');
			}		
    	}

    }
}
