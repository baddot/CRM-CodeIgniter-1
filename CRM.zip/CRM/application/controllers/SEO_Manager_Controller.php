<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SEO_Manager_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');

		$this->load->model('SEO_Manager_Model');	
	}

	public function show_records(){
		if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$data['item'] = $this->SEO_Manager_Model->fetch_all();
		$this->load->view('pages/SEO_Manager_Dashboard',$data);
	}

	public function view_profile(){
    	if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$data['item'] = $this->SEO_Manager_Model->view_profile();
		
		$this->load->view('pages/SEO_Manager_Profile', $data);
    }

    public function password_reset(){		//For loading the view
    	if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$this->load->view('pages/SEO_Manager_Password_Reset');
    }

    public function change_password(){		//For changing the password
    	if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$new_password = $this->input->post('password_confirmation');
		
		$len = strlen($new_password);
		
		if($len>=6){
			$encrypt_password = password_hash($new_password, PASSWORD_BCRYPT);
			$this->SEO_Manager_Model->change_password($encrypt_password);

			$this->session->set_flashdata('seo_msg',' ');
			redirect(base_url().'index.php/SEO_Manager_Controller/password_reset');
		}
	}

	public function store_comment($sales_id){
    	if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
    	$comment = $this->input->post('comment');

    	if($comment != '')
    		$this->SEO_Manager_Model->store_comment($sales_id, $comment);

    	redirect(base_url().'index.php/SEO_Manager_Controller/show_records');
    }

    public function update_seo_keywords($sales_id){
    	if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$keyword = $this->input->post('keyword');

		$this->SEO_Manager_Model->update_seo_keywords($sales_id,$keyword);
		$this->session->set_flashdata('seo_msg',' ');
		redirect(base_url().'index.php/SEO_Manager_Controller/show_records');
    }

    public function fetchTicket(){
		if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$data['item'] = $this->SEO_Manager_Model->fetchTicket();
		
		$this->load->view('pages/SEO_Manager_Tickets',$data);
	}

	public function ticketDetails($id){
		if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}
		
		$data['item'] = $this->SEO_Manager_Model->ticketDetails($id);
		$data['msg'] = $this->SEO_Manager_Model->fetchMsg($data['item'][0]->ticket_id);

		$this->load->view('pages/SEO_Manager_Ticket_Details',$data);
	}

	public function reply($id,$ticket_id){
		if(!$this->authVerifier->verifySEOManager()){
			redirect(base_url().'index.php/Form_Controller');
		}

		$reply = $this->input->post('reply');
		if($reply != '')
			$this->SEO_Manager_Model->reply($ticket_id, $reply);

		redirect(base_url().'index.php/SEO_Manager_Controller/ticketDetails/'.$id);
    }
}
