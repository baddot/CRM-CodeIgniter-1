<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 18-Jul-17
 * Time: 10:53 AM
 */
class Auth extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function login(){
		if($this->input->method() === 'get'){
			if(!$this->authVerifier->verifyAccountsManager())
				$this->load->view('AccountManage/login.html');
			else
				$this->load->view('AccountManage/dash.html');
		}
		elseif ($this->input->method() === 'post'){
			$validationRules = array(
				array(
					'field' => 'email',
					'label' => 'E-mail',
					'rules' => 'required|valid_email'
				),
				array(
					'field' => 'password',
					'label' => 'Password',
					'rules' => 'required|min_length[6]'
				)
			);
			$this->form_validation->set_rules($validationRules);
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('errors', validation_errors());
				redirect(base_url().'index.php/accountManager/login');
			}
			else
			{
				$email    = $this->input->post('email');
				$password = $this->input->post('password');
				$criteria = array(
					'email' => $email,
					'department' => 40,
					'lead_type' => 1,
					'status' => 1
				);
				$user     = $this->db->where($criteria)->get('crm_user')->result();
				if (count($user) === 1)
				{
					$user = $user[0];
					if (password_verify($password, $user->password))
					{
						unset($user->password);
						$this->session->set_userdata('accMan', $user);
						redirect(base_url().'index.php/Ac_Manager_Controller/show_records');

//						TODO: Account Manager Dashboard codes here

					}
					else
					{
						$this->session->set_flashdata('errors', 'Invalid credentials');
						redirect(base_url() . 'index.php/accountManager/login');
					}
				}
				else
				{
					$this->session->set_flashdata('errors', 'Account manager with these credentials not found');
					redirect(base_url() . 'index.php/accountManager/login');
				}
			}
		}
	}

	function logout(){
		if($this->session->userdata('accMan'))
		{
			$this->session->unset_userdata('accMan');
			$this->session->set_flashdata('loggedOut', 'Logged out successfully');
		}
		else
			$this->session->set_flashdata('errors', 'No account manager signed in to log out');
		redirect(base_url().'index.php/accountManager/login');
	}
}