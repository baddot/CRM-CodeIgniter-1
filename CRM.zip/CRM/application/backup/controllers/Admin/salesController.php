<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 14-Jul-17
 * Time: 2:57 PM
 */
class salesController extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function showSales(){
		if($this->authVerifier->verifyAdmin()){
			if($this->input->get('id')){
				$id = $this->input->get('id');
				$sale = $this->db->where('sales_id', $id)->get('crm_sales_update_table')->result();
				if(count($sale)){
					$sale = $sale[0];
					echo json_encode(array('code' => 200, 'msg' => 'Sale details found', 'data' => $sale));
				}
				else
					echo json_encode(array('code' => 404, 'msg' => 'Unable to find the required sales info'));
			}
			else{
				$sales = $this->db->get('crm_sales_update_table')->result();
				if(count($sales)){
					$index = 1;
					$data = array($index => null);
					foreach ($sales as $sale){
						$data[$index]['sale'] = $sale;
						$user = $this->db->where('id', $sale->user_id)->get('crm_user')->result();
						if(count($user)){
							$user = $user[0];
							unset($user->password);
							$data[$index]['user'] = $user;
						}
						else
							$data[$index]['user'] = 'User not found';
						$index++;
					}
					echo json_encode(array('code' => 200, 'msg' => 'Sales found', 'data' => $data));
				}
				else
					echo json_encode(array('code' => 404, 'msg' => 'No sales yet'));
			}
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as  admin'));
	}

	function editSaleData($id){
		if($this->authVerifier->verifyAdmin())
		{
			$formData = $this->input->post();
			$cardArray = array(
				'card_number' => null,
				'name_on_card' => null,
				'exp_date' => null,
				'cvv' => null
			);
			if(isset($formData['card_num'])){
				$cardArray['card_number'] = $formData['card_num'];
				unset($formData['card_num']);
				if(isset($formData['card_name'])){
					$cardArray['name_on_card'] = $formData['card_name'];
					unset($formData['card_name']);
				}
				if(isset($formData['card_exp'])){
					$cardArray['exp_date'] = $formData['card_exp'];
					unset($formData['card_exp']);
				}
				if(isset($formData['card_cvv'])){
					$cardArray['cvv'] = $formData['card_cvv'];
					unset($formData['card_cvv']);
				}
			}
			$updSale = $this->db->where('sales_id', $id)->update('crm_sales_update_table', $formData);
			if($updSale)
			{
				if($cardArray['card_number'] && $cardArray['exp_date'] && $cardArray['name_on_card']){
					$whereCard = array(
//						'card_number' => $cardArray['card_number'],
						'sales_id' => $id
					);
					$isCardPresent = $this->db->where($whereCard)->get('crm_card_details')->result();
					if(count($isCardPresent)){
						$updateCardDetails = $this->db->where($whereCard)->update('crm_card_details', $cardArray);
						if($updateCardDetails)
							echo json_encode(array('code' => 200, 'msg' => 'Sales & card data updated successfully'));
						else
							echo json_encode(array('code' => 500, 'msg' => 'Error, Sales data updated however the card data was not. Please try again'));
					}
					else{
						$insertCard = $this->db->insert('crm_card_details', $cardArray);
						if($insertCard)
							echo json_encode(array('code' => 200, 'msg' => 'Sales data updated & card data inserted successfully'));
						else
							echo json_encode(array('code' => 500, 'msg' => 'Error, sales data updated but unable to insert card data. Please try again'));
					}
				}
				else
					echo json_encode(array('code' => 200, 'msg' => 'Sales data updated successfully'));
			}
			else
				echo json_encode(array('code' => 500, 'msg' => 'Internal error'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as  admin'));
	}

}