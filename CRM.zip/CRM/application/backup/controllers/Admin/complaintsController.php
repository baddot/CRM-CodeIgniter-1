<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 18-Jul-17
 * Time: 2:42 PM
 */
class complaintsController extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function getAllComplaints(){
		if($this->authVerifier->verifyAdmin()){
			if($this->input->method() === 'get'){
				$complaints = $this->db->get('complaints')->result();
				if(count($complaints)){
					foreach ($complaints as $complaint){
						$complaintUser = $this->db->where('uid', $complaint->from)->get('users')->result();
						if(count($complaintUser)){
							$complaintUser = $complaintUser[0];
							unset($complaintUser->password, $complaintUser->api_token, $complaintUser->remember_token);
							$complaint->user = $complaintUser;
						}
					}
					echo json_encode(array('code' => 200, 'msg' => 'Complaints found', 'data' => $complaints));
				}
				else
					echo json_encode(array('code' => 404, 'msg' => 'No complaints found'));
			}
			else
				echo json_encode(array('code' => 403, 'msg' => 'Unrecognised request method'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
	}

	function deleteComplaint($id){
		if($this->authVerifier->verifyAdmin())
		{
			if ($this->input->method() === 'get')
			{
				/*
				$delComplaint = $this->db->where('id', $id)->delete('complaints');
				if($delComplaint)
					echo json_encode(array('code' => 200, 'msg' => 'Complaint successfully deleted'));
				else
					echo json_encode(array('code' => 500, 'msg' => 'Internal error. Unable to delete complaint'));
				*/
				echo json_encode(array('code' => 405, 'msg' => 'This functionality is disabled for now'));
			}
			else
				echo json_encode(array('code' => 403, 'msg' => 'Unrecognised request method.'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
	}

	function showComplaint($id){
		if($this->authVerifier->verifyAdmin()){
			if($this->input->method() === 'get'){
				$complaint = $this->db->where('id', $id)->get('complaints')->result();
				if(count($complaint)){
					$complaint = $complaint[0];
					$toUser = null;
					$complaintUser = $this->db->where('uid', $complaint->from)->get('users')->result();
					if(count($complaintUser)){
						$complaintUser = $complaintUser[0];
						unset($complaintUser->password, $complaintUser->api_token, $complaintUser->remember_token);
						$complaint->user = $complaintUser;
					}
					$description = $this->db->where('ticket_id', $complaint->complaint_id)->get('crm_ticket')->result();
					if(count($description)){
						$description = $description[0];
						$description = $description->description;
						if(!$description)
							$description = '';
						$complaint->description = $description;
					}
					if($complaint->to)
						$toUser = $this->db->where('uid', $complaint->to)->get('users')->result();
					if(count($toUser)){
						$toUser = $toUser[0];
						unset($toUser->password, $toUser->api_token, $toUser->remember_token);
						$complaint->toUser = $toUser;
					}
					$issueType = $this->db->where('value', 'Issue Type')->get('crm_category')->result();
					if(count($issueType)){
						$issueTypeId = $issueType[0]->cat_id;
						$issueTypes = $this->db->where('parent', $issueTypeId)->get('crm_category')->result();
						if(count($issueTypes)){
							$data = array(
								'complaint' => $complaint,
								'issueTypes' => $issueTypes
							);
							echo json_encode(array('code' => 200, 'msg' => 'Details retrieved', 'data' => $data));
						}
						else
							echo json_encode(array('code' => 500, 'msg' => 'Internal error, issue types not found'));
					}
					else
						echo json_encode(array('code' => 500, 'msg' => 'Internal error, parent issue type not found'));
				}
				else
					echo json_encode(array('code' => 404, 'msg' => 'Complaint not found!'));
			}
			else
				echo json_encode(array('code' => 403, 'msg' => 'Unrecognised request method'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
	}

	function editComplaint($complaintId){
		if($this->authVerifier->verifyAdmin()){
			if($this->input->post()){
				$formData = $this->input->post();
				$description = $formData['description'];
				$formData['updated_at'] = gmdate('Y-m-d H:i:s', time());
				unset($formData['description']);
				$updComplaint = $this->db->where('complaint_id', $complaintId)->update('complaints', $formData);
				$checkFlag = false;
				if($updComplaint){
					$data = array(
						'description' => $description,
					    'updated_at' => $formData['updated_at']
					);
					$updTicket = $this->db->where('ticket_id', $complaintId)->update('crm_ticket', $data);
					if($updTicket)
						$checkFlag = true;
					else
						$checkFlag = false;
					if($checkFlag)
					{
						$this->session->set_flashdata('succMsg', 'Complaint successfully updated');
						redirect(base_url() . 'index.php/admin/dash');
					}
					else{
						$this->session->set_flashdata('errors', 'Internal error, unable to update complaint');
						redirect(base_url() . 'index.php/admin/dash');
					}
				}
				else{
					$this->session->set_flashdata('errors', 'Internal error, unable to update complaint');
					redirect(base_url() . 'index.php/admin/dash');
				}
			}
			else{
				$this->session->set_flashdata('errors', 'Unrecognised request method');
				redirect(base_url() . 'index.php/admin/login');
			}
		}
		else
		{
			$this->session->set_flashdata('errors', 'You do not have administrative privileges');
			redirect(base_url() . 'index.php/admin/login');
		}
	}

}