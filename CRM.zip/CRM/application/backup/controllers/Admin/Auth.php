<?php
/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 03-Jul-17
 * Time: 2:53 PM
 */

class Auth extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function login(){
		if($this->input->method() == 'get')
		{
			if(!$this->authVerifier->verifyAdmin())
				$this->load->view('Admin/login.html');
			else
				redirect(base_url().'index.php/admin/dash');
		}
		elseif ($this->input->method() == 'post')
		{
			$validationRules = array(
				array(
					'field' => 'email',
					'label' => 'E-mail',
					'rules' => 'required|valid_email'
				),
				array(
					'field' => 'password',
					'label' => 'Password',
					'rules' => 'required|min_length[6]'
				)
			);
			$this->form_validation->set_rules($validationRules);
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('errors', validation_errors());
				redirect(base_url().'index.php/admin/login');
			}
			else
			{
				$email    = $this->input->post('email');
				$password = $this->input->post('password');
				$user     = $this->db->where('email', $email)->get('crm_admin')->result();
				if (count($user) === 1)
				{
					$user = $user[0];
					if (password_verify($password, $user->password))
					{
						unset($user->password);
						$this->session->set_userdata('admin', $user);
						redirect(base_url() . 'index.php/admin/dash');
					}
					else
					{
						$this->session->set_flashdata('errors', 'Invalid credentials');
						redirect(base_url() . 'index.php/admin/login');
					}
				}
				else
				{
					$this->session->set_flashdata('errors', 'Admin not found');
					redirect(base_url() . 'index.php/admin/login');
				}
			}
		}
	}

	function logout(){
		if($this->session->userdata('admin'))
		{
			$this->session->unset_userdata('admin');
			$this->session->set_flashdata('loggedOut', 'Logged out successfully');
		}
		else
			$this->session->set_flashdata('errors', 'No admin signed in to log out');
		redirect(base_url().'index.php/admin/login');
	}

}