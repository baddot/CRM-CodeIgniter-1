<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 03-Jul-17
 * Time: 4:02 PM
 */
class AdminController extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function dashboard(){
		if($this->authVerifier->verifyAdmin())
		{
			/*$userList = $this->db->get('user')->result();
			$categoryList = $this->db->get('category')->result();
			if(count($userList)){
				foreach ($userList as $user)
					unset($user->password);
				$userList = json_encode($userList);
			}
			if(count($categoryList)){
				$categoryList = json_encode($categoryList);
			}*/
//			var_dump($userList);
//			die();
			$this->load->view('Admin/dash.html', array(/*'users' => $userList, 'categories' => $categoryList, */'admin' => $this->session->userdata('admin')));
		}
		else
		{
			redirect(base_url().'index.php/admin/login');
		}
	}

	function editProfile(){
		if($this->authVerifier->verifyAdmin()){
			$formData = $this->input->post();
			$rules = array(
				array(
					'field' => 'password',
					'label' => 'Password',
					'rules' => 'min_length[6]'
				),
				array(
					'field' => 'confPassword',
					'label' => 'Confirm Password',
					'rules' => 'matches[password]'
				)
			);
			$this->form_validation->set_rules($rules);
			if ($this->form_validation->run() == FALSE)
			{
				$this->session->set_flashdata('errors', validation_errors());
				redirect(base_url().'index.php/admin/dash');
			}
			else
			{
				$id         = $this->session->userdata('admin')->id;
				if ($formData['password'])
				{
					$getOldPassHash = $this->db->where('id', $id)->get('crm_admin')->result();
					if (count($getOldPassHash))
						$getOldPassHash = $getOldPassHash[0]->password;
					else
					{
						$this->session->set_flashdata('errors', '500. Internal error');
						redirect(base_url().'index.php/admin/logout');
					}
					if(password_verify($formData['password'], $getOldPassHash)){
						$this->session->set_flashdata('errors', 'New & old password are the same, operation halted');
						redirect(base_url().'index.php/admin/dash');
					}
					if(password_verify($formData['oldPassword'], $getOldPassHash))
					{
						$formData['password'] = password_hash($formData['password'], PASSWORD_BCRYPT);
						unset($formData['confPassword'], $formData['oldPassword']);
					}
					else
					{
						$this->session->set_flashdata('errors', '403. Incorrect old password, operation halted');
						redirect(base_url().'index.php/admin/dash');
					}
				}
				else
					unset($formData['password'], $formData['confPassword'], $formData['oldPassword']);
				$updAdmin = $this->db->where('id', $id)->update('crm_admin', $formData);
				if ($updAdmin)
				{
					$retrieveAdmin = $this->db->where('id', $id)->get('crm_admin')->result();
					if (count($retrieveAdmin))
					{
						$admin = $retrieveAdmin[0];
						unset($retrieveAdmin, $admin->password);
						$this->session->set_userdata('admin', $admin);
						$this->session->set_flashdata('successMsg', 'Admin profile info updated successfully');
						redirect(base_url() . 'index.php/admin/dash');
					}
					else
					{
						$this->session->set_flashdata('errors', 'Database error. Unable to retrieve admin info');
						redirect(base_url() . 'index.php/admin/logout');
					}
				}
				else{
					$this->session->set_flashdata('errors', 'Database error. Unable to update admin info');
					redirect(base_url() . 'index.php/admin/logout');
				}
			}
		}
		else{
			echo '403, access denied';
			if($this->session->userdata('admin'))
				$this->session->unset_userdata('admin');
			redirect(base_url().'index.php/admin/login');
		}
	}

	function getUserList(){
		if($this->authVerifier->verifyAdmin())
		{
			$userList = $this->db->get('crm_user')->result();
			if(count($userList)){
				foreach ($userList as $user)
				{
					unset($user->password);
					$getDept = $this->db->where('cat_id', $user->department)->get('crm_category')->result();
					if(count($getDept)){
						$user->department = $getDept[0]->value;
						$getDept = null;
					}
					else
						$user->department = 'N/A';
					if($user->manager_id !== '0'){
						$getMgr = $this->db->where('id', $user->manager_id)->get('crm_user')->result();
						if(count($getMgr)){
							unset($getMgr[0]->password);
							$user->mgr = $getMgr[0];
						}
						else
							$user->mgr = null;
						$getMgr = null;
					}
					else
						$user->mgr = null;
				}
				$userList = json_encode($userList);
				echo $userList;
			}
			else
				echo json_encode(array('code' => 404, 'msg' => 'No users yet'));
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in at admin'));
	}

	function getCategoryList(){
		if($this->authVerifier->verifyAdmin()){
			$categoryList = $this->db->get('crm_category')->result();
			if(count($categoryList)){
				$categoryList = json_encode($categoryList);
			}
			echo $categoryList;
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in at admin'));
	}

	function addUser(){
		if($this->authVerifier->verifyAdmin())
		{
			$data = $this->input->post();
			$data['time'] = gmdate('Y-m-d H:i:s', time());
			$data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
			$checkForUser = $this->db->where('email', $data['email'])->get('crm_user')->result();
			if(count($checkForUser)){
				echo json_encode(array('code' => 400, 'msg' => 'email already exists in users table'));
			}
			else{
				$insertData = $this->db->insert('crm_user', $data);
				if($insertData)
				{
					echo json_encode(array('code' => 200, 'msg' => 'New user created'));
					redirect(base_url().'index.php/admin/dash');
				}
				else
					echo json_encode(array('code' => 500, 'msg' => 'Internal error'));
			}
		}
		else
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in at admin'));
	}

	function delUser($id){
		if($this->authVerifier->verifyAdmin()){
			$delUser = $this->db->where('id', $id)->delete('crm_user');
			if ($delUser){
				echo json_encode(array('code' => 200, 'msg' => 'User deleted successfully'));
			}
			else{
				echo json_encode(array('code' => 500, 'msg' => 'Internal error'));
			}
		}
		else{
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in at admin'));
			redirect(base_url().'index.php/admin/login');
		}
	}

	function getUserDetailsForEdit($id){
		if($this->authVerifier->verifyAdmin()){
			$user = $this->db->where('id', $id)->get('crm_user')->result();
			if(count($user)){
				$user = $user[0];
				unset($user->password);
				$categories = $this->db->get('crm_category')->result();
				if(count($categories))
					echo json_encode(array('user' => $user, 'categories' => $categories, 'mgrs' => $this->getManagers()));
				else
					echo json_encode(array('code' => 500, 'msg' => 'Internal error, unable to retrieve categories'));
			}
			else{
				echo json_encode(array('code' => 404, 'msg' => 'User not found'));
			}
		}
		else{
			echo json_encode(array('code' => 403, 'msg' => 'You are not signed in as admin'));
		}
	}

	function editUser(){
		if($this->authVerifier->verifyAdmin()){
			$data = $this->input->post();
			if($data['password'] == '')
				unset($data['password']);
			else
				$data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
			$id = $data['userId'];
			unset($data['userId']);
			$editUser = $this->db->where('id', $id)->update('crm_user', $data);
			if($editUser)
				redirect(base_url().'index.php/admin/dash');
			else
				echo json_encode(array('code' => 500, 'msg' => 'Internal Server error'));
		}
		else{
			redirect(base_url().'index.php/admin/login');
		}
	}

	function getManagers(){
		if($this->authVerifier->verifyAdmin()){
			$mgrs = $this->db->where('lead_type', '1')->get('crm_user')->result();
			if(count($mgrs))
			{
				foreach ($mgrs as $mgr)
					unset($mgr->password);
				return $mgrs;
			}
			else
				return null;
		}
		return null;
	}

}