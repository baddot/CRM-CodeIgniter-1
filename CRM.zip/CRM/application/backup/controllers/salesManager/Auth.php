<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 18-Jul-17
 * Time: 8:41 AM
 */
class Auth extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}

	function login(){
		if($this->input->method() === 'get'){
			if(!$this->authVerifier->verifySalesManager())
				$this->load->view('Sales/login.html');
			else
				redirect(base_url().'index.php/Sales_Manager_Controller/show_records');
		}
		elseif ($this->input->method() === 'post'){
			$validationRules = array(
				array(
					'field' => 'email',
					'label' => 'E-mail',
					'rules' => 'required|valid_email'
				),
				array(
					'field' => 'password',
					'label' => 'Password',
					'rules' => 'required|min_length[6]'
				)
			);
			$this->form_validation->set_rules($validationRules);
			if ($this->form_validation->run() == FALSE){
				$this->session->set_flashdata('errors', validation_errors());
				redirect(base_url().'index.php/sales/login');
			}
			else
			{
				$email    = $this->input->post('email');
				$password = $this->input->post('password');
				$criteria = array(
					'email' => $email,
					'department' => 16,
					'lead_type' => 1,
					'status' => 1
				);
				$user     = $this->db->where($criteria)->get('crm_user')->result();
				if (count($user) === 1)
				{
					$user = $user[0];
					if (password_verify($password, $user->password))
					{
						unset($user->password);
						$this->session->set_userdata('saleMan', $user);
						redirect(base_url().'index.php/Sales_Manager_Controller/show_records');

//						TODO: Sales Manager Dashboard codes here

					}
					else
					{
						$this->session->set_flashdata('errors', 'Invalid credentials');
						redirect(base_url() . 'index.php/sales/login');
					}
				}
				else
				{
					$this->session->set_flashdata('errors', 'Sales manager with these credentials not found');
					redirect(base_url() . 'index.php/sales/login');
				}
			}
		}
	}

	function logout(){
		if($this->session->userdata('saleMan'))
		{
			$this->session->unset_userdata('saleMan');
			$this->session->set_flashdata('loggedOut', 'Logged out successfully');
		}
		else
			$this->session->set_flashdata('errors', 'No sales manager signed in to log out');
		redirect(base_url().'index.php/sales/login');
	}
}