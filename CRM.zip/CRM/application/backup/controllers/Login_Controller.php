<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');

		$this->load->model('Login_Model');
	}
	public function login_func(){
		if($this->input->post()){
			$email =  $this->input->post('email');
			$pswrd = $this->input->post('pswrd');

			if($email && $pswrd){
				$data = $this->Login_Model->login($email, $pswrd);

				if($data == 1){
					$this->session->set_userdata('login_email', $email);
					redirect(base_url().'index.php/Form_Controller');
				}
				else{
					echo "<script> alert('Invalid Credentials') </script>";
					redirect('/','refresh');
				}
			}
		}
	}
}
