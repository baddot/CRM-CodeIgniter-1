<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_Controller extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->helper('form');

		$this->load->library('session');

		$this->load->model('Form_Model');
	}

	public function index($data = 2){
		if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php/Pages_Controller');
		}

		$arr['token'] = $data;
		$this->load->view('pages/form',$arr);
	}

	public function store_details(){
		$data = $this->input->post();
		if($data['cus_name'] && $data['bus_name'] && $data['bus_abn'] && $data['email'] && $data['p_type'] && $data['domain_selector']){
			if($this->Form_Model->store_form_data($data) == 1)
				redirect(base_url().'index.php/Form_Controller/index/1');
			else
				redirect(base_url().'index.php/Form_Controller/index/0');
		}
	}

	public function update($sales_id){
		if(!$this->session->userdata('login_email')){
			redirect(base_url().'index.php/Form_Controller');
		}
		$data = $this->input->post();
		$status = $this->Form_Model->update($sales_id, $data);

		if($status == 1){
			redirect(base_url().'index.php/Pages_Controller/fetchAll/1');
		}
	}
}
