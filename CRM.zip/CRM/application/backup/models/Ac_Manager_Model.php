<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ac_Manager_Model extends CI_Model {
	public function __construct(){
		$this->load->database();
	}
	public function fetch(){
        //return $this->db->query("select crm_sales_update_table.*, crm_card_details.card_id, crm_card_details.name_on_card, crm_card_details.card_number, crm_card_details.exp_date, crm_card_details.cvv, crm_comment.* from crm_sales_update_table left join crm_card_details on crm_sales_update_table.sales_id = crm_card_details.sales_id left JOIN crm_comment on crm_sales_update_table.sales_id = crm_comment.sales_id where crm_sales_update_table.sales_manager_status = '1' order by crm_sales_update_table.sales_id desc")->result();

        return $this->db->query("select crm_sales_update_table.*, crm_card_details.card_id, crm_card_details.name_on_card, crm_card_details.card_number, crm_card_details.exp_date, crm_card_details.cvv from crm_sales_update_table left join crm_card_details on crm_sales_update_table.sales_id = crm_card_details.sales_id where sales_manager_status = '1' order by sales_id desc")->result();
    }

    public function fetchAgent($id){
        return $this->db->where('id',$id)->get('crm_user')->result();
    }

    public function approve($sales_id){
        $this->db->where('sales_id',$sales_id)->update('crm_sales_update_table', array('ac_manager_status' => 1));
    }

    public function fetchTicket(){
        return $this->db->query("select crm_ticket.id, crm_ticket.ticket_id, crm_ticket.title, crm_ticket.type, crm_ticket.status, crm_ticket.description, crm_ticket.created_at, users.name, users.surname, users.email, clients.website from crm_ticket left join users on crm_ticket.from = users.uid inner join clients on users.uid = clients.uid order by id desc")->result();
    }

    public function ticketDetails($id){
        return $this->db->query("select crm_ticket.id, crm_ticket.ticket_id, crm_ticket.title, crm_ticket.type, crm_ticket.status, crm_ticket.description, crm_ticket.created_at, users.name, users.surname, users.email, clients.website from crm_ticket left join users on crm_ticket.from = users.uid inner join clients on users.uid = clients.uid where crm_ticket.id = '$id'")->result();
    }

    public function fetchMsg($ticket_id){
        return $this->db->where('ticket_id',$ticket_id)->order_by('created_at', 'DESC')->get('ticket_reply')->result();
    }

    public function reply($ticket_id,$f_name,$l_name,$reply){
        $data['ticket_id'] = $ticket_id;
        $data['ticket_from'] = $f_name.' '.$l_name;
        $data['replied_by'] = '2';
        $data['reply_from'] = $this->session->userdata('accMan')->email;
        $data['reply'] = $reply;

       $this->db->insert('ticket_reply',$data);
    }

      public function status_update($ticket_id, $status){
        $data['status'] = $status;
        
        $this->db->update('crm_ticket', $data, "ticket_id = '$ticket_id'");
    }

    public function store_comment($sales_id, $comment){
        $data['sales_id'] = $sales_id;
        $data['comment_by'] = $this->session->userdata('accMan')->name;
        $data['comment'] = $comment;

        $this->db->insert('crm_comment',$data);
    }

    public function dep_sel($dept){
         return $this->db->query("select crm_user.name from crm_user left join crm_category on crm_user.department = crm_category.cat_id where crm_category.value = '$dept';")->result();
    }

    public function forward_ticket($ticket_id, $emp_name){
        $emp_id = $this->db->where('name',$emp_name)->get('crm_user')->result();
        
        $data['emp_id'] = $emp_id[0]->id;
        $data['ticket_id'] = $ticket_id;

        $this->db->insert('crm_ticket_forward',$data);
    }

    public function view_profile(){
        $user_id = $this->session->userdata('accMan')->id;

        return $this->db->query("select A.*, B.value from crm_user as A left join crm_category as B on A.department = B.cat_id where A.id = '$user_id'")->result();
    }

    public function change_password($pswrd){
        $user_id = $this->session->userdata('accMan')->id;
        $data['password'] = $pswrd;
        
        $this->db->update('crm_user', $data, "id = '$user_id'");
    }
}