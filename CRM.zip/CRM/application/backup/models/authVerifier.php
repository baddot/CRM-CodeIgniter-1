<?php

/**
 * Created by PhpStorm.
 * User: Nextweb
 * Date: 17-Jul-17
 * Time: 2:44 PM
 */
class authVerifier extends CI_Model
{
	public function verifyAdmin(){
		if($this->session->userdata('admin')){
			$sessAdm = $this->session->userdata('admin');
			$orgAdm = $this->db->where('id', $sessAdm->id)->get('crm_admin')->result();
			if(count($orgAdm)){
				$orgAdm = $orgAdm[0];
				unset($orgAdm->password);
				foreach ($orgAdm as $key=>$value){
					if($sessAdm->$key !== $value)
						return false;
				}
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}

	public function verifySalesManager(){
		if($this->session->userdata('saleMan')){
			$sess = $this->session->userdata('saleMan');
			$org = $this->db->where('id', $sess->id)->get('crm_user')->result();
			if(count($org)){
				$org = $org[0];
				unset($org->password);
				foreach ($org as $key=>$value){
					if($sess->$key !== $value)
						return false;
				}
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}

	public function verifyAccountsManager(){
		if($this->session->userdata('accMan')){
			$sess = $this->session->userdata('accMan');
			$org = $this->db->where('id', $sess->id)->get('crm_user')->result();
			if(count($org)){
				$org = $org[0];
				unset($org->password);
				foreach ($org as $key=>$value){
					if($sess->$key !== $value)
						return false;
				}
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}
}