<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_Model extends CI_Model {
	public function __construct(){
		$this->load->database();
	}
	
    public function view_profile(){
        $user_id = $this->session->userdata('user_id');

        return $this->db->query("select A.*, B.value, C.name as manager_name from crm_user as A left join crm_category as B on A.department = B.cat_id inner join crm_user as C on A.manager_id = C.id where A.id = '$user_id'")->result();
    }

    public function change_password($pswrd){
    	$user_id = $this->session->userdata('user_id');
    	$data['password'] = $pswrd;
    	
    	$this->db->update('crm_user', $data, "id = '$user_id'");
    }
}