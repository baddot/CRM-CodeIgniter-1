<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Form_Model extends CI_Model {
	public function __construct(){
		$this->load->database();
	}
	public function store_form_data($parameters){
        $data['user_id'] = $this->session->userdata('user_id');

        $data['customer_name'] = $parameters['cus_name'];
        $data['business_name'] = $parameters['bus_name'];
        $data['abn'] = $parameters['bus_abn'];
        $data['business_type'] = $parameters['bus_type'];
        $data['business_address'] = $parameters['bus_add'];
        $data['phone'] = $parameters['phone'];
        $data['email_id'] = $parameters['email'];
        $data['areas'] = $parameters['areas'];
        $data['services'] = $parameters['services'];
        $data['payment_type'] = $parameters['p_type'];


        $data['domain'] = $parameters['domain_selector'];
        $data['domain_name'] = $parameters['domain_name'];
        $data['domain_suggestions'] = $parameters['domain_suggestions'];
        $data['time_to_call'] = $parameters['best_time'];
        $data['tc_sent'] = $parameters['t&c'];
        $data['invoice_sent'] = $parameters['invoice'];
        $data['product_type'] = $parameters['category_selector'];
        $data['template_sent'] = $parameters['w_template'];
        $data['template_selected'] = $parameters['template_selected'];
        $data['questionnaire_sent'] = $parameters['ques_sent'];
        $data['questionnaire_received'] = $parameters['ques_recv'];
        $data['keyword_select'] = $parameters['seo_keywords'];
        $data['keyword_not_select_reason'] = $parameters['reason'];
        $data['email_sent_for_login'] = $parameters['login_cred_sent'];
        $data['login_credential_received'] = $parameters['login_cred_recv'];
        $data['comments'] = $parameters['comment'];

        $data['created_on'] = date("Y-m-d");
        $data['time'] = date("Y-m-d h:m:s");

        $this->db->insert('crm_sales_update_table',$data);
        
        $card_data['sales_id'] = $this->db->insert_id();

        if($parameters['p_type'] == 'Card'){
            $card_data['name_on_card'] = $parameters['card_name'];
            $card_data['card_number'] = $parameters['card_num'];
            $card_data['exp_date'] = $parameters['card_exp'];
            $card_data['cvv'] = $parameters['card_cvv'];
            
            $this->db->insert('crm_card_details',$card_data);
        }
        return 1;
    }

    public function fetchAll($user_id){
        return $this->db->query("select crm_sales_update_table.*, crm_card_details.card_id, crm_card_details.name_on_card, crm_card_details.card_number, crm_card_details.exp_date, crm_card_details.cvv from crm_sales_update_table left join crm_card_details on crm_sales_update_table.sales_id = crm_card_details.sales_id where user_id = '$user_id' order by sales_id desc")->result();
    }

    public function update($sales_id, $parameters){

        $data['user_id'] = $this->session->userdata('user_id');

        $data['customer_name'] = $parameters['cus_name'];
        $data['business_name'] = $parameters['bus_name'];
        $data['abn'] = $parameters['bus_abn'];
        $data['business_type'] = $parameters['bus_type'];
        $data['business_address'] = $parameters['bus_add'];
        $data['phone'] = $parameters['phone'];
        $data['email_id'] = $parameters['email'];
        $data['areas'] = $parameters['areas'];
        $data['services'] = $parameters['services'];
        $data['payment_type'] = $parameters['p_type'];


        $data['domain'] = $parameters['domain_selector'];
        $data['domain_name'] = $parameters['domain_name'];
        $data['domain_suggestions'] = $parameters['domain_suggestions'];
        $data['time_to_call'] = $parameters['best_time'];
        $data['tc_sent'] = $parameters['t&c'];
        $data['invoice_sent'] = $parameters['invoice'];
        $data['product_type'] = $parameters['category_selector'];
        $data['template_sent'] = $parameters['w_template'];
        $data['template_selected'] = $parameters['template_selected'];
        $data['questionnaire_sent'] = $parameters['ques_sent'];
        $data['questionnaire_received'] = $parameters['ques_recv'];
        $data['keyword_select'] = $parameters['seo_keywords'];
        $data['keyword_not_select_reason'] = $parameters['reason'];
        $data['email_sent_for_login'] = $parameters['login_cred_sent'];
        $data['login_credential_received'] = $parameters['login_cred_recv'];
        $data['comments'] = $parameters['comment'];

        if($data['domain'] == 'New Domain')
            $data['domain_name'] = '';
        if($data['domain'] == 'Existing Domain')
            $data['domain_suggestions'] = '';

        if($data['keyword_select'] != 'NO')
            $data['keyword_not_select_reason'] = '';

        $temp = $this->db->query("select payment_type from crm_sales_update_table where sales_id = '$sales_id'")->result();

        if($parameters['p_type'] == 'EFT'){
            if(($temp[0]->payment_type) == 'Card'){
                $card_data['status'] = 0;
                $this->db->update('crm_card_details', $card_data, "sales_id = '$sales_id'");
            }
        }

        if($parameters['p_type'] == 'Card'){
            $card_data['name_on_card'] = $parameters['card_name'];
            $card_data['card_number'] = $parameters['card_num'];
            $card_data['exp_date'] = $parameters['card_exp'];
            $card_data['cvv'] = $parameters['card_cvv'];
            
            if(($temp[0]->payment_type) == 'Card')
                $this->db->update('crm_card_details', $card_data, "sales_id = '$sales_id'");
            
            if(($temp[0]->payment_type) == 'EFT'){
                $card_data['sales_id'] = $sales_id;
                $this->db->insert('crm_card_details',$card_data);
            }
        }

        $this->db->update('crm_sales_update_table', $data, "sales_id = '$sales_id'");
        return 1;
    }

    public function store_comment($sales_id, $comment){
        $data['sales_id'] = $sales_id;
        $data['comment_by'] = $this->session->userdata('login_email');
        $data['comment'] = $comment;

        $this->db->insert('crm_comment',$data);
    }
}