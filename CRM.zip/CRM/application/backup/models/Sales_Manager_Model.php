<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales_Manager_Model extends CI_Model {
	public function __construct(){
		$this->load->database();
	}
	public function fetch(){
        //return $this->db->query("select crm_sales_update_table.*, crm_card_details.card_id, crm_card_details.name_on_card, crm_card_details.card_number, crm_card_details.exp_date, crm_card_details.cvv from crm_sales_update_table left join crm_card_details on crm_sales_update_table.sales_id = crm_card_details.sales_id order by sales_id desc")->result();
        $id = $this->session->userdata('saleMan')->id;

        return $this->db->query("select crm_sales_update_table.*, crm_card_details.card_id, crm_card_details.name_on_card, crm_card_details.card_number, crm_card_details.exp_date, crm_card_details.cvv from crm_sales_update_table left join crm_card_details on crm_sales_update_table.sales_id = crm_card_details.sales_id left join crm_user on crm_sales_update_table.user_id = crm_user.id where crm_user.manager_id = '$id' order by sales_id desc")->result();
    }

    public function fetchAgent($id){
        return $this->db->where('id',$id)->get('crm_user')->result();
    }

    public function approve($sales_id){
        $this->db->where('sales_id',$sales_id)->update('crm_sales_update_table', array('sales_manager_status' => 1));
    }

    public function store_comment($sales_id, $comment){
        $data['sales_id'] = $sales_id;
        $data['comment_by'] = $this->session->userdata('saleMan')->name;
        $data['comment'] = $comment;

        $this->db->insert('crm_comment',$data);
    }

    public function view_profile(){
        $user_id = $this->session->userdata('saleMan')->id;

        return $this->db->query("select A.*, B.value from crm_user as A left join crm_category as B on A.department = B.cat_id where A.id = '$user_id'")->result();
    }

    public function change_password($pswrd){
        $user_id = $this->session->userdata('saleMan')->id;
        $data['password'] = $pswrd;
        
        $this->db->update('crm_user', $data, "id = '$user_id'");
    }
}