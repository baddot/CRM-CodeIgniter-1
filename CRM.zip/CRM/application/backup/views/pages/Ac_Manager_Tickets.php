<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class=""><a style = "color:white;" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Account Manager Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">View Projects</a></li>
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/fetchTicket">View Tickets</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><font color = "white">Hello, <?php echo $this->session->userdata('accMan')->name; ?></font> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/ac_logout">Logout</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/view_profile">View Profile</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/password_reset">Change Password</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container" style="margin-top: 100px;">
            <div class="row user-row">    
                <div class="col-xs-8 col-sm-9 col-md-10 col-lg-10">
                    <div class="row col-md-12 col-md-offset-1 custyle" style = "border : 2px solid lightgrey; border-radius: 15px;">
                        <h3>Tickets</h3>
                        <hr>
                        <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>Ticket ID.</th>
                                <th>Customer Name</th>
                                <th>Website</th>
                                <th>Issue Title</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php
                                foreach($item as $elem){
                            ?>
                              <tr>
                                <td><?php echo $elem->ticket_id?></td>
                                <td><?php echo $elem->name." ".$elem->surname?></td>
                                <td><?php echo $elem->website?></td>
                                <td><?php echo $elem->title?></td>
                                <td><?php echo $elem->created_at?></td>
                                <td><?php echo $elem->status?></td>
                                <td><a href ="<?php echo base_url().'index.php/Ac_Manager_Controller/ticketDetails/'.$elem->id?>"><button class = "btn btn-success">View Ticket</button></a></td>
                              </tr>
                            <?php
                                }
                             ?>
                            </tbody>
                        </table>
                    </div>              
                </div>
            </div>
        </div>
    </div>
</body>

<script type="text/javascript" src = "<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
    $('ul.nav li.dropdown').hover(function() {
       $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });

    $(document).ready(function() {
        var panels = $('.user-infos');
        var panelsButton = $('.dropdown-user');
        panels.hide();

        panelsButton.click(function() {
            var dataFor = $(this).attr('data-for');
            var idFor = $(dataFor);

            var currentButton = $(this);
                idFor.slideToggle(400, function() {
                    if(idFor.is(':visible'))
                        currentButton.html('<i class="glyphicon glyphicon-chevron-up text-muted"></i>');
                    else
                        currentButton.html('<i class="glyphicon glyphicon-chevron-down text-muted"></i>');
                })
    });

    $('[data-toggle="tooltip"]').tooltip();
        $('button').click(function(e) {
            e.preventDefault();
            alert("This is a demo.\n :-)");
        });
    });
</script>
</html>