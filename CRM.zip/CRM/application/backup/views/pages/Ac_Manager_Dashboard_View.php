<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class=""><a style = "color:white;" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Account Manager Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">View Projects</a></li>
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/fetchTicket">View Tickets</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><font color = "white">Hello, <?php echo $this->session->userdata('accMan')->name; ?></font> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/ac_logout">Logout</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/view_profile">View Profile</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/password_reset">Change Password</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container" style = "margin-top : 100px">
        <div class="row">
            <div class="col-sm-3 col-md-3">
              <div class="panel-group" id="accordion">
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion"><span class="glyphicon glyphicon-folder-close">
                        </span> Tickets</a>
                    </h4>
                  </div>
                  <div id="collapseOne" class="panel-collapse collapse in">
                    <ul class="list-group">
                    <?php
                        foreach($item as $elem){
                    ?>
                      <li class="list-group-item"><span class="fa fa-ticket"></span><a style = "cursor : pointer;" onclick = "show('<?php echo $elem->ticket_id;?>')">  <?php echo $elem->title;?></a><span class="badge">Posted By <?php echo $elem->name;?></span></li>
                    <?php
                        }
                    ?>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-9 col-md-8" id = "div_<?php echo $elem->ticket_id;?>" name = "show_div">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Ticket Details</h3>
                    </div>
                    <div class="panel-body">
                        <div class="col-md-12">
                            <div class="well-block">
                                <div class="well-title">
                                    <h2></h2>
                                </div>
                                <form>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="name">Ticket Title</label>
                                                <input id="name" name="name" type="text" placeholder="Ticket Title" class="form-control input-md" value = "<?php echo $item[0]->title;?>" disabled>
                                            </div>
                                        </div>
                                     
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="time">Ticket type</label>
                                                <select id="time" name="time" class="form-control" disabled>
                                                    <option value="<?php echo $item[0]->type;?>"><?php echo $item[0]->type;?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="time">Ticket Status</label>
                                                <select id="time" name="time" class="form-control" disabled>
                                                    <option value="<?php echo $item[0]->status;?>"><?php echo $item[0]->status;?></option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Description</label>
                                                <textarea rows = "5" placeholder="Website" class="form-control input-md" disabled><?php echo $item[0]->description;?></textarea>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Created At</label>
                                                <input id="date" name="date" type="text" placeholder="Created At" class="form-control input-md" value = "<?php echo $item[0]->created_at;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Posted By</label>
                                                <input id="date" name="date" type="text" placeholder="Posted By" class="form-control input-md" value = "<?php echo $item[0]->name;?>"disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Email</label>
                                                <input id="date" name="date" type="text" placeholder="Email" class="form-control input-md" value = "<?php echo $item[0]->email;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Website</label>
                                                <input id="date" name="date" type="text" placeholder="Website" class="form-control input-md" value = "<?php echo $item[0]->website;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-12" hidden>
                                            <div class="form-group">
                                                <button id="singlebutton" name="singlebutton" class="btn btn-default">Make An Appointment</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
                foreach ($item as $elem) {
            ?>
            <div class="col-sm-9 col-md-8" id = "div_<?php echo $elem->ticket_id;?>" name = "show_div" hidden>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Ticket Details</h3>
                    </div>
                    <div class="panel-body">
                        <div class="col-md-12">
                            <div class="well-block">
                                <div class="well-title">
                                    <h2></h2>
                                </div>
                                <form>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="name">Ticket Title</label>
                                                <input id="name" name="name" type="text" placeholder="Ticket Title" class="form-control input-md" value = "<?php echo $elem->title;?>" disabled>
                                            </div>
                                        </div>
                                     
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="time">Ticket type</label>
                                                <select id="time" name="time" class="form-control" disabled>
                                                    <option value="<?php echo $elem->type;?>"><?php echo $elem->type;?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="time">Ticket Status</label>
                                                <select id="time" name="time" class="form-control" disabled>
                                                    <option value="<?php echo $elem->status;?>"><?php echo $elem->status;?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Description</label>
                                                <textarea rows = "5" placeholder="Ticket Description" class="form-control input-md" disabled><?php echo $elem->description;?></textarea>
                                            </div>
                                        </div>
                                    
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Created At</label>
                                                <input id="date" name="date" type="text" placeholder="Created At" class="form-control input-md" value = "<?php echo $elem->created_at;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Posted By</label>
                                                <input id="date" name="date" type="text" placeholder="Posted By" class="form-control input-md" value = "<?php echo $elem->name;?>"disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Email</label>
                                                <input id="date" name="date" type="text" placeholder="Email" class="form-control input-md" value = "<?php echo $elem->email;?>" disabled>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label" for="date">Website</label>
                                                <input id="date" name="date" type="text" placeholder="Website" class="form-control input-md" value = "<?php echo $elem->website;?>" disabled>
                                            </div>
                                        </div>
                                        <div class="col-md-12" hidden>
                                            <div class="form-group">
                                                <button id="singlebutton" name="singlebutton" class="btn btn-default">Make An Appointment</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
        </div>
    </div>
</body>

<script type="text/javascript" src = "<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
    function show(id){
        $('div[name=show_div').hide();
        $('#div_'+id).show();
    }

    $('ul.nav li.dropdown').hover(function() {
       $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });

    $(document).ready(function() {
        var panels = $('.user-infos');
        var panelsButton = $('.dropdown-user');
        panels.hide();

        panelsButton.click(function() {
            var dataFor = $(this).attr('data-for');
            var idFor = $(dataFor);

            var currentButton = $(this);
                idFor.slideToggle(400, function() {
                    if(idFor.is(':visible'))
                        currentButton.html('<i class="glyphicon glyphicon-chevron-up text-muted"></i>');
                    else
                        currentButton.html('<i class="glyphicon glyphicon-chevron-down text-muted"></i>');
                })
    });

    $('[data-toggle="tooltip"]').tooltip();
        $('button').click(function(e) {
            e.preventDefault();
            alert("This is a demo.\n :-)");
        });
    });
</script>
</html>