<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Form_Controller" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a style = "background-color:#f5f5f5;" href="<?php echo base_url()?>index.php/Form_Controller">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">User Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/Form_Controller">Add New Sale</a></li>
                            <li><a href="<?php echo base_url()?>index.php/Pages_Controller/fetchAll">List All Sales</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                    <a href="#" style = "color:white"  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hello, <?php echo $this->session->userdata('name');?> <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/agent_logout">Logout</a></li>
                        <li><a href="<?php echo base_url();?>index.php/Pages_Controller/view_profile">View Profile</a></li>
                        <li><a href="<?php echo base_url();?>index.php/Pages_Controller/password_reset">Change Password</a></li>
                    </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    
	<div class="container" style="margin-top: 100px;">
        <form class="well form-horizontal" action="<?php echo base_url();?>index.php/Form_Controller/store_details" method="post"  id="contact_form" onsubmit = "return form_submission()" style = "background-color : white;">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
			<fieldset> 
				<legend>After Sales Update</legend>
                <?php
                    if($token == 1){
                ?>

                <div class="alert alert-success" role="alert" id="success_message">Success <i class="glyphicon glyphicon-thumbs-up"></i> Thanks for contacting us, we will get back to you shortly...</div>
                <?php
                    }
                    if($token == 0){
                ?>

                <div class="alert alert-danger" role="alert" id="failed_message">Failed <i class="glyphicon glyphicon-thumbs-down"></i> Fail to submit the form...</div>
                <?php
                    }
                ?>

                <div class="form-group">
  					<label class="col-md-4 control-label">Customer Name*</label>  
  					<div class="col-md-4 inputGroupContainer">
  						<div class="input-group">
  							<span class="input-group-addon"><i class="fa fa-user fa-lg"></i></span>
  							<input name="cus_name" placeholder="Customer Name" class="form-control"  type="text" id = "cus_name" required autofocus>
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Business Name*</label>  
  					<div class="col-md-4 inputGroupContainer">
  						<div class="input-group">
  							<span class="input-group-addon"><i class="fa fa-suitcase"></i></span>
  							<input  name="bus_name" placeholder="Business Name" class="form-control"  type="text" id = "bus_name" required autofocus>
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Business ABN*</label>  
  					<div class="col-md-4 inputGroupContainer">
  						<div class="input-group">
  							<span class="input-group-addon"><i class="fa fa-briefcase"></i></span>
  							<input  name="bus_abn" placeholder="Business ABN" class="form-control"  type="text" id = "bus_abn" required autofocus>
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Business Type</label>  
  					<div class="col-md-4 inputGroupContainer">
  						<div class="input-group">
  							<span class="input-group-addon"><i class="fa fa-briefcase"></i></span>
  							<input  name="bus_type" placeholder="Business Type" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Business Address</label>
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-building"></i></span>
        					<textarea rows = "5" class="form-control" name="bus_add" placeholder="Business Address"></textarea>
  						</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Phone Number</label>  
  					<div class="col-md-4 inputGroupContainer">
  						<div class="input-group">
  							<span class="input-group-addon"><i class="fa fa-phone fa-lg"></i></span>
  							<input  name="phone" placeholder="Phone Number" class="form-control"  type="text">
    					</div>
  					</div>
				</div>

       			<div class="form-group">
  					<label class="col-md-4 control-label">E-Mail ID*</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
  							<input name="email" placeholder="E-Mail Address" class="form-control"  type="email" id = "email" required autofocus>
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Areas</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-map-marker fa-lg"></i></span>
  							<input name="areas" placeholder="Areas" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Service</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-cogs"></i></span>
  							<input name="services" placeholder="Service" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Payment Type (Card/EFT)*</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-dollar fa-lg"></i></span>
    						<select name="p_type" id = "payment_selector" class="form-control selectpicker" required autofocus>
      							<option value = "">Select</option>
      							<option value = "Card">Card</option>
      							<option value = "EFT">EFT</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group" id = "card_payment_section" hidden> 
  					<label class="col-md-3 control-label"></label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<div class="container">
								<div class="row">
									<div class="col-xs-12 col-md-5">
										<div class="panel panel-default credit-card-box" style = "padding:10px">
											<div class="panel-heading display-table" >
												<div class="row display-tr" >
													<h3 class="panel-title display-td" ><b>&nbsp&nbsp&nbsp Payment Details</b></h3>
													<div class="display-td" >                            
														<img class="img-responsive pull-right" src="http://i76.imgup.net/accepted_c22e0.png">
													</div>
												</div>                    
											</div>
											<div class="panel-body">
											<div role="form" id="payment-form">
												<div class="row">
													<div class="col-xs-12">
														<div class="form-group">
															<label for="cardNumber">Name on the card</label>
															<div class="input-group">
																<input type="text" class="form-control" name="card_name" id = "card_name" placeholder="Name on Card"/>
																<span class="input-group-addon"><i class="fa fa-user"></i></span>
															</div>
														</div>                            
													</div>
												</div>
												<div class="row">
													<div class="col-xs-12">
														<div class="form-group">
															<label for="cardNumber">Card Number</label>
															<div class="input-group">
																<input type="text" class="form-control" name="card_num" id = "card_num" placeholder="Valid Card Number"/>
																<span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
															</div>
														</div>                            
													</div>
												</div>
												<div class="row">
													<div class="col-xs-7 col-md-7">
														<div class="form-group">
															<label for="cardExpiry">Exp Date</label>
															<input type="text" class="form-control" name="card_exp" id = "card_exp" placeholder="MM / YY"/>
														</div>
													</div>
													<div class="col-xs-5 col-md-5 pull-right">
														<div class="form-group">
															<label for="cardCVC">CVV</label>
															<input type="password" class="form-control" name="card_cvv" id = "card_cvv" placeholder="CVV" autocomplete="false"/>
														</div>
													</div>
												</div>
											</div>
											</div>
										</div>            
									</div>            
								</div>
							</div>
  						</div>
					</div>
				</div>

				<div class="form-group">
                    <label class="col-md-4 control-label">Domain?</label>
                    <div class="col-md-4">
                        <div class="radio">
                            <label>
                        	    <input type="radio" name="domain_selector" id = "domain_radio1" value="New Domain" required autofocus /> New Domain
                    	    </label>
                    	    &nbsp&nbsp&nbsp&nbsp
                    	    <label>
                                <input type="radio" name="domain_selector" id = "domain_radio2" value="Existing Domain" required autofocus="" /> Existing Domain
                            </label>
                        </div>
                    </div>
                </div>

				<div class="form-group" id = "existing_domain" hidden>
  					<label class="col-md-4 control-label">Domain Name</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-globe"></i></span>
  							<input name="domain_name" placeholder="Domain Name" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group" id = "new_domain" hidden>
  					<label class="col-md-4 control-label">Domain Suggestions</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-globe"></i></span>
  							<input name="domain_suggestions" placeholder="Domain Suggestions" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Best Time</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="	glyphicon glyphicon-time"></i></span>
  							<input name="best_time" placeholder="Best Time" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Terms and conditions Sent (YES/NO)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-pencil-square-o"></i></span>
    						<select name="t&c" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Invoice sent (YES/NO)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="fa fa-pencil-square-o"></i></span>
    						<select name="invoice" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Website/SEO</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="category_selector" class="form-control selectpicker" >
      							<option value = "Website">Website</option>
      							<option value = "SEO">SEO</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Website Template Sent (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="w_template" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Template selected (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="template_selected" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Web Basic Questionnaire Sent (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="ques_sent" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Web Basic Questionnaire Received (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="ques_recv" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">SEO keywords Selected (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="seo_keywords" id = "keyword_selector" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group" id = "reason" hidden>
  					<label class="col-md-4 control-label">If No, Why?</label>  
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
  							<input name="reason" placeholder="If No, Why?" class="form-control" type="text">
    					</div>
  					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Email sent for Login Credential (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    						<select name="login_cred_sent" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group"> 
  					<label class="col-md-4 control-label">Login Credential Received (YES/NO/NA)</label>
    				<div class="col-md-4 selectContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="	fa fa-key"></i></span>
    						<select name="login_cred_recv" class="form-control selectpicker" >
      							<option value = "YES">YES</option>
      							<option value = "NO">NO</option>
      							<option value = "NA">NA</option>
    						</select>
  						</div>
					</div>
				</div>

				<div class="form-group">
  					<label class="col-md-4 control-label">Overall comments if any</label>
    				<div class="col-md-4 inputGroupContainer">
    					<div class="input-group">
        					<span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
        					<textarea rows = "6" style = "width : 400px" class="form-control" name="comment" placeholder="Comments"></textarea>
  						</div>
  					</div>
				</div>
                <hr>
				<center>
				<div class="form-group">
  					<label class="col-md-4 control-label"></label>
  					<div class="col-md-4">
    					<input type="submit" value = "Submit Form" name = "submit" class="btn btn-success">
    					<button type="reset" class="btn btn-info" >Reset</button>
  					</div>
				</div>
			</fieldset>
		</form>
	</div>
</body>

<script type="text/javascript" src = "<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src = "<?php echo base_url();?>assets/js/style.js"></script>
<script type="text/javascript">
    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
        });
</script>
</html>