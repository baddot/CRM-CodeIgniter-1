<!DOCTYPE html>
<html>
<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/style_comment_box.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
    <div id = "main_div">
    <div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a style = "background-color:#f5f5f5;" href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Account Manager Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records">View Projects</a></li>
                            <li><a href="<?php echo base_url()?>index.php/Ac_Manager_Controller/fetchTicket">View Tickets</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><font color = "white">Hello, <?php echo $this->session->userdata('accMan')->name; ?></font> <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/ac_logout">Logout</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/view_profile">View Profile</a></li>
                            <li><a href="<?php echo base_url(); ?>index.php/Ac_Manager_Controller/password_reset">Change Password</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container" style="margin-top: 100px;">
            <div class="row user-row">    
                <div class="col-xs-8 col-sm-9 col-md-10 col-lg-10">
                    <div class="row col-md-12 col-md-offset-1 custyle" style = "border : 2px solid lightgrey; border-radius: 15px;">
                        <h3>Recent Projects</h3>
                        <hr>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Customer Name</th>
                                    <th>Business Name</th>
                                    <th>Agent Name</th>
                                    <th>Date</th>
                                    <th class="text-center">Actions</th>
                                </tr>
                            </thead>
                            <?php
                                foreach($item as $e){
                            ?>
                            <tr>
                                <td><?php echo $e->customer_name;?></td>
                                <td><?php echo $e->business_name;?></td>
                                <td><?php echo $e->agentName;?></td>
                                <td><?php echo $e->created_on;?></td>
                                <td class="text-center">
                                    <?php
                                        if($e->ac_manager_status === '0'){
                                    ?>
                                    <a href = "<?php echo base_url().'index.php/Ac_Manager_Controller/approve/'.$e->sales_id;?>"><input type = "button" class='btn btn-warning' id = "edit_btn_<?php echo $e->sales_id?>" onclick ="edit(<?php echo $e->sales_id?>)" value = "Approve"></a>
                                    <?php
                                        }
                                        else{
                                    ?>
                                    <a><input type = "button" class='btn btn-warning' value = "Approved" disabled></a>
                                    <?php
                                        }
                                        
                                    ?>
                                    
                                    <input type ="button" class='btn btn-success' onclick ="show(<?php echo $e->sales_id?>)" value = "Show Details">
                                    <input type ="button" id = "cmnt_btn_<?php echo $e->sales_id;?>" onclick ="show_comment(<?php echo $e->sales_id?>)" class='btn btn-info' value = "Comment">
                                    <div id="myModal_<?php echo $e->sales_id?>" class="modal">
                                        <div class="modal-content">
                                            <span style = "float : right; cursor : pointer;" id = "close_<?php echo $e->sales_id?>" class="close_<?php echo $e->sales_id?>">&times;</span>
                                            <div class="row">
                                                <div class="col-sm-12">
                                                    <h3>Comments</h3>
                                                </div>
                                            </div>
                                            <hr>
                                            <?php 
                                                $this->db->from('crm_comment');
                                                $query = $this->db->where('sales_id',$e->sales_id)->order_by('commented_at', 'DESC')->get();
                                                foreach ($query->result() as $row) {
                                            ?>
                                            <div class="row" id = "comment_area_<?php echo $e->sales_id?>">
                                                <div class="col-sm-2">
                                                    <div class="thumbnail">
                                                        <img class="img-responsive user-photo" src="https://ssl.gstatic.com/accounts/ui/avatar_2x.png">
                                                    </div>
                                                </div>
                                                <div class="col-sm-10">
                                                    <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <strong>Commented By : <?php echo $row->comment_by?></strong> <br><span class="text-muted">Date & Time : <?php echo $row->commented_at?></span>
                                                        </div>
                                                    <div class="panel-body">
                                                        <?php echo $row->comment?>
                                                    </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                }
                                            ?>
                                            <div class="row">
                                                <form action = "<?php echo base_url();?>index.php/Ac_Manager_Controller/store_comment/<?php echo $e->sales_id?>" method = "post">
                                                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                                                    <div class="col-sm-12">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                                            <textarea rows = "5" class="form-control" name="comment" placeholder="Post Your Comments"><?php echo $e->comments;?></textarea>
                                                        </div>                                   
                                                    </div>
                                                    <br>
                                                    <br>
                                                    <div class="col-sm-2">
                                                        <label></label>
                                                        <div class="input-group">
                                                            <input type="submit" class="btn btn-success green" value = "Submit">
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td colspan = "5" id = "div<?php echo $e->sales_id?>" hidden>
                                    <div class="panel panel-default well">
                                        <div class="panel-body">
                                            <form action="" class="form-horizontal track-event-form bv-form" data-goaltype="”General”" data-formname="”ContactUs”" method="post" id="contact-us-all" novalidate="novalidate">
                                                <div class="form-group">               
                                                    <div class="col-sm-6">
                                                        <label>Customer Name*</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-user fa-lg"></i></span>
                                                            <input name="cus_name" placeholder="Customer Name" class="form-control" type="text" id = "cus_name_<?php echo $e->sales_id;?>" value = "<?php echo $e->customer_name;?>" required autofocus>
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>                
                                                    <div class="col-sm-6">
                                                        <label>Business Name*</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-suitcase"></i></span>
                                                            <input  name="bus_name" placeholder="Business Name" class="form-control"  type="text" id = "bus_name_<?php echo $e->sales_id;?>" value = "<?php echo $e->business_name;?>" required autofocus>
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                </div>

                                                <div class="form-group">               
                                                    <div class="col-sm-6">
                                                        <label>Business ABN*</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-briefcase"></i></span>
                                                            <input  name="bus_abn" placeholder="Business ABN" class="form-control"  type="text" id = "bus_abn_<?php echo $e->sales_id;?>" value = "<?php echo $e->abn;?>" required autofocus>
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>Business Type</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-briefcase"></i></span>
                                                            <input  name="bus_type" placeholder="Business Type" class="form-control" type="text" value = "<?php echo $e->business_type;?>">
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                </div>

                                                <div class="form-group">               
                                                    <div class="col-sm-12">
                                                        <label>Business Address</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-building"></i></span>
                                                            <textarea rows = "4" class="form-control" name="bus_add" placeholder="Business Address"><?php echo $e->business_address;?></textarea>
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                </div>

                                                <div class="form-group">               
                                                    <div class="col-sm-6">
                                                        <label>Phone Number</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-phone fa-lg"></i></span>
                                                            <input  name="phone" placeholder="Phone Number" class="form-control"  type="text" value = "<?php echo $e->phone;?>">
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>E-Mail ID*</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                                            <input name="email" placeholder="E-Mail Address" class="form-control"  type="email" id = "email_<?php echo $e->sales_id;?>" value = "<?php echo $e->email_id;?>" required autofocus>
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                </div>

                                                <div class="form-group">               
                                                    <div class="col-sm-6">
                                                        <label>Areas</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-map-marker fa-lg"></i></span>
                                                            <input name="areas" placeholder="Areas" class="form-control" type="text" value = "<?php echo $e->areas;?>">
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>Service</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-cogs"></i></span>
                                                            <input name="services" placeholder="Service" class="form-control" type="text" value = "<?php echo $e->services;?>">
                                                        </div>
                                                        <small data-bv-validator="notEmpty" data-bv-validator-for="C_FirstName" class="help-block" style="display: none;">Required</small>
                                                    </div>
                                                </div>
                                                    
                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>Payment Type (Card/EFT)*</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-dollar fa-lg"></i></span>
                                                            <select name="p_type" id = "payment_selector_<?php echo $e->sales_id?>" class="form-control selectpicker" onchange = "payment_sel(<?php echo $e->sales_id;?>)" required autofocus>
                                                                <?php
                                                                    if($e->payment_type == 'Card'){
                                                                ?>
                                                                <option value = "<?php echo $e->payment_type;?>"><?php echo $e->payment_type;?></option>
                                                                <option value = "EFT">EFT</option>
                                                                <?php
                                                                }
                                                                    if($e->payment_type == 'EFT'){
                                                                ?>
                                                                <option value = "<?php echo $e->payment_type;?>"><?php echo $e->payment_type;?></option>
                                                                <option value = "Card">Card</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                        
                                                    </div>
                                                </div>
                                               
                                               <div class = "form-group" id = "payment_sec_<?php echo $e->sales_id;?>">
                                                    <div class = "col-sm-8">
                                                        <h3>Payment Details</h3>
                                                        <div class="panel-body" style = "border : 2px solid lightgrey; border-radius : 10px; padding : 25px">
                                                            <div role="form" id="payment-form">
                                                                <div class="row">
                                                                    <div class="col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="cardNumber">Name on the card</label>
                                                                            <div class="input-group">
                                                                                <input type="text" class="form-control" name="card_name" id = "card_name_<?php echo $e->sales_id;?>" placeholder="Name on Card" value = "<?php echo $e->name_on_card;?>"/>
                                                                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                                                            </div>
                                                                        </div>                            
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-xs-12">
                                                                        <div class="form-group">
                                                                            <label for="cardNumber">Card Number</label>
                                                                            <div class="input-group">
                                                                                <input type="text" class="form-control" name="card_num" id = "card_num_<?php echo $e->sales_id;?>" placeholder="Valid Card Number" value = "<?php echo $e->card_number?>"/>
                                                                                <span class="input-group-addon"><i class="fa fa-credit-card"></i></span>
                                                                            </div>
                                                                        </div>                            
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-xs-7 col-md-7">
                                                                        <div class="form-group">
                                                                            <label for="cardExpiry">Exp Date</label>
                                                                            <input type="text" class="form-control" name="card_exp" id = "card_exp_<?php echo $e->sales_id;?>" placeholder="MM / YY" value = "<?php echo $e->exp_date?>"/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xs-5 col-md-5 pull-right">
                                                                        <div class="form-group">
                                                                            <label for="cardCVC">CVV</label>
                                                                            <input type="password" class="form-control" name="card_cvv" id = "card_cvv_<?php echo $e->sales_id;?>" placeholder="CVV" value = "<?php echo $e->cvv?>"/>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>Domain?</label>
                                                        <div class="radio">
                                                        <?php
                                                            if($e->domain == "New Domain"){
                                                        ?>
                                                            <label>
                                                                <input type="radio" name="domain_selector" class = "radio_<?php echo $e->sales_id?>" value="New Domain" required autofocus checked /> New Domain
                                                            </label>
                                                            &nbsp&nbsp&nbsp&nbsp
                                                            <label>
                                                                <input type="radio" name="domain_selector" class = "radio_<?php echo $e->sales_id?>" value="Existing Domain" required autofocus="" /> Existing Domain
                                                            </label>

                                                        <?php
                                                            }
                                                            if($e->domain == "Existing Domain"){
                                                        ?>
                                                            <label>
                                                                <input type="radio" name="domain_selector" class = "radio_<?php echo $e->sales_id?>" value="New Domain" required autofocus /> New Domain
                                                            </label>
                                                            &nbsp&nbsp&nbsp&nbsp
                                                            <label>
                                                                <input type="radio" name="domain_selector" class = "radio_<?php echo $e->sales_id?>" value="Existing Domain" required autofocus="" checked /> Existing Domain
                                                            </label>

                                                        <?php
                                                            }
                                                        ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6" name = "div_exist_<?php echo $e->sales_id?>" id = "existing_domain" hidden>
                                                        <label>Domain Name</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-globe"></i></span>
                                                            <input name="domain_name" placeholder="Domain Name" class="form-control" type="text" value = "<?php echo $e->domain_name;?>">
                                                        </div>                                   
                                                    </div>
                                                    <div class="col-sm-6" name = "div_new_<?php echo $e->sales_id?>" id = "new_domain" hidden>
                                                    <label>Domain Suggestions</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-globe"></i></span>
                                                            <input name="domain_suggestions" placeholder="Domain Suggestions" class="form-control" type="text" value = "<?php echo $e->domain_suggestions;?>">
                                                        </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>Best Time</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="  glyphicon glyphicon-time"></i></span>
                                                            <input name="best_time" placeholder="Best Time" class="form-control" type="text" value = "<?php echo $e->time_to_call;?>">
                                                        </div>                                   
                                                    </div>
                                                    <div class="col-sm-6">
                                                    <label>Terms and conditions Sent (YES/NO)</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-pencil-square-o"></i></span>
                                                        <select name="t&c" class="form-control selectpicker" >
                                                            <?php
                                                                if($e->tc_sent == 'YES'){
                                                            ?>
                                                            <option value = "<?php echo $e->tc_sent;?>"><?php echo $e->tc_sent;?></option>
                                                            <option value = "NO">NO</option>
                                                            <?php
                                                                }
                                                                if($e->tc_sent == 'NO'){
                                                            ?>
                                                            <option value = "<?php echo $e->tc_sent;?>"><?php echo $e->tc_sent;?></option>
                                                            <option value = "YES">YES</option>
                                                            <?php
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>Invoice sent (YES/NO)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-pencil-square-o"></i></span>
                                                            <select name="invoice" class="form-control selectpicker">
                                                                <?php
                                                                    if($e->invoice_sent == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->invoice_sent;?>"><?php echo $e->invoice_sent;?></option>
                                                                <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                    if($e->invoice_sent == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->invoice_sent;?>"><?php echo $e->invoice_sent;?></option>
                                                                <option value = "YES">YES</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>Website/SEO</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="category_selector" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->product_type == 'Website'){
                                                                ?>
                                                                <option value = "<?php echo $e->product_type;?>"><?php echo $e->product_type;?></option>
                                                                <option value = "SEO">SEO</option>
                                                                <?php
                                                                    }
                                                                    if($e->product_type == 'SEO'){
                                                                ?>
                                                                <option value = "<?php echo $e->product_type;?>"><?php echo $e->product_type;?></option>
                                                                <option value = "Website">Website</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>Website Template Sent (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="w_template" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->template_sent == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->template_sent;?>"><?php echo $e->template_sent;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->template_sent == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->template_sent;?>"><?php echo $e->template_sent;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->template_sent == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->template_sent;?>"><?php echo $e->template_sent;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>Template selected (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="template_selected" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->template_selected == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->template_selected;?>"><?php echo $e->template_selected;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->template_selected == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->template_selected;?>"><?php echo $e->template_selected;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->template_selected == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->template_selected;?>"><?php echo $e->template_selected;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>Web Basic Questionnaire Sent (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="ques_sent" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->questionnaire_sent == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->questionnaire_sent;?>"><?php echo $e->questionnaire_sent;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->questionnaire_sent == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->questionnaire_sent;?>"><?php echo $e->questionnaire_sent;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->questionnaire_sent == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->questionnaire_sent;?>"><?php echo $e->questionnaire_sent;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>Web Basic Questionnaire Received (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="ques_recv" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->questionnaire_received == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->questionnaire_received;?>"><?php echo $e->questionnaire_received;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->questionnaire_received == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->questionnaire_received;?>"><?php echo $e->questionnaire_received;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->questionnaire_received == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->questionnaire_received;?>"><?php echo $e->questionnaire_received;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-6">
                                                        <label>SEO keywords Selected (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="seo_keywords" id = "keyword_selector_<?php echo $e->sales_id;?>" class="form-control selectpicker" onchange = "keyword(<?php echo $e->sales_id;?>)">
                                                                <?php
                                                                    if($e->keyword_select == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->keyword_select;?>"><?php echo $e->keyword_select;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->keyword_select == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->keyword_select;?>"><?php echo $e->keyword_select;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->keyword_select == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->keyword_select;?>"><?php echo $e->keyword_select;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                    <div class="col-sm-6" id = "reason_<?php echo $e->sales_id;?>">
                                                        <label>If No, Why?</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                                            <input name="reason" placeholder="If No, Why?" class="form-control" type="text" value = "<?php echo $e->keyword_not_select_reason?>">
                                                        </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">  
                                                    <div class="col-sm-6">
                                                        <label>Email sent for Login Credential (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="login_cred_sent" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->email_sent_for_login == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->email_sent_for_login;?>"><?php echo $e->email_sent_for_login;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->email_sent_for_login == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->email_sent_for_login;?>"><?php echo $e->email_sent_for_login;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->email_sent_for_login == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->email_sent_for_login;?>"><?php echo $e->email_sent_for_login;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <label>Login Credential Received (YES/NO/NA)</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                                                            <select name="login_cred_recv" class="form-control selectpicker" >
                                                                <?php
                                                                    if($e->login_credential_received == 'YES'){
                                                                ?>
                                                                <option value = "<?php echo $e->login_credential_received;?>"><?php echo $e->login_credential_received;?></option>
                                                                <option value = "NO">NO</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->login_credential_received == 'NO'){
                                                                ?>
                                                                <option value = "<?php echo $e->login_credential_received;?>"><?php echo $e->login_credential_received;?></option>
                                                                <option value = "YES">YES</option>
                                                                <option value = "NA">NA</option>
                                                                <?php
                                                                    }
                                                                    if($e->login_credential_received == 'NA'){
                                                                ?>
                                                                    <option value = "<?php echo $e->login_credential_received;?>"><?php echo $e->login_credential_received;?></option>
                                                                    <option value = "YES">YES</option>
                                                                    <option value = "NO">NO</option>
                                                                <?php
                                                                    }
                                                                ?>
                                                            </select>
                                                        </div>                                   
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <div class="col-sm-12">
                                                        <label>Overall comments if any</label>
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
                                                            <textarea rows = "6" class="form-control" name="comment" placeholder="Comments"><?php echo $e->comments;?></textarea>
                                                        </div>                                   
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </td>     
                            </tr>
                            <?php
                                }
                            ?>
                        </table>
                    </div>              
                </div>
            </div>
        </div>
    </div>
    </div>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script type="text/javascript">
        
    function show_comment(id){
        $(document.body).load( "<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records #main_div", function() {
            var modal = document.getElementById("myModal_"+id);
            var btn = document.getElementById("cmnt_btn_"+id);
            var span = document.getElementsByClassName("close_"+id)[0];

            modal.style.display = "block";

            span.onclick = function() {
                modal.style.display = "none";
                $(document.body).load( "<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records");
            }

            window.onclick = function(event) {
                if (event.target == modal) {
                    modal.style.display = "none";
                    $(document.body).load( "<?php echo base_url()?>index.php/Ac_Manager_Controller/show_records");
                }
            }
        });
    }
</script>

<script type="text/javascript">

    function show(k){
        $("#div"+k+" :input").prop('disabled', true);
        $("#forward_"+k+" :input").prop('disabled', false);
        $('#div'+k).slideToggle("slow");

        var p = $('input[type=radio][class=radio_'+k+']:checked').val();

        if(p == 'Existing Domain')
            $('div[name=div_exist_'+k+']').show();
        else if(p == 'New Domain')
            $('div[name=div_new_'+k+']').show();

        var p_type = $('#payment_selector_'+k).val();
        
        if(p_type == 'EFT')
            $('#payment_sec_'+k).hide();

        var temp = $("#keyword_selector_"+k).val();
        if(temp == 'NO')
            $("#reason_"+k).show();
        else
            $("#reason_"+k).hide();
    }

    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
    });

    $(document).ready(function() {
        var panels = $('.user-infos');
        var panelsButton = $('.dropdown-user');
        panels.hide();

        panelsButton.click(function() {
            var dataFor = $(this).attr('data-for');
            var idFor = $(dataFor);

            var currentButton = $(this);
            idFor.slideToggle(400, function() {
                if(idFor.is(':visible'))
                    currentButton.html('<i class="glyphicon glyphicon-chevron-up text-muted"></i>');
                else
                    currentButton.html('<i class="glyphicon glyphicon-chevron-down text-muted"></i>');
            })
        });

        //$('[data-toggle="tooltip"]').tooltip();
            
        $('button').click(function(e) {
            e.preventDefault();
            alert("This is a demo.\n :-)");
        });
    });
</script>
</html>