<!DOCTYPE html>
<html>
    <head>
        <title></title>
              <link rel = "stylesheet" href = "<?php echo base_url();?>assets/css/style.css">
    </head>

    <body>
        <div class="pen-title">
            <h1>Login</h1>
        </div>
        <div class="module form-module">
            <div class=""></div>
            <div class="form">
                <h2>Login to your account</h2>
                <form action="<?php echo base_url()?>index.php/Login_Controller/login_func" method="POST" onsubmit = "return validate()">
                    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                    <input type="email" name = "email" id = "email" placeholder="Email ID"/>
                    <input type="password" name = "pswrd" id = "pswrd" placeholder="Password"/>
                    <button type="submit">Login</button>
                </form>
            </div>
            <div class="cta"><a href="#">&copy; Nextweb</a></div>
        </div>
    </body>
    <script type="text/javascript">
        function validate(){
            var email = document.getElementById('email').value;
            var pswrd = document.getElementById('pswrd').value;

            if(email && pswrd)
                return true;
            else
                alert('All the fields are mandatory');
                return false;
        }
    </script>
</html>