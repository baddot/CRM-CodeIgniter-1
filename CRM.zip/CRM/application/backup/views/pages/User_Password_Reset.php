<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>assets/css/bootstrap.css">
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body>
	<div class="navbar navbar-default navbar-fixed-top" style = "background-color: #d64848">
        <div class="container">
            <div class="navbar-header">
                <button button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" rel="home" href="<?php echo base_url()?>index.php/Form_Controller" title="Buy Sell Rent Everyting">
                    <img style="max-width:100px; margin-top: 5px;"
                     src="https://www.nextweb.com.au/images/main-logo.png">
                </a>
            </div>
        
            <div id="navbar" class="collapse navbar-collapse navbar-responsive-collapse">
                <ul class="nav navbar-nav">
                    <li class=""><a style = "color:white;" href="<?php echo base_url()?>index.php/Form_Controller">Home</a></li>
                    <li class="dropdown">
                        <a style = "color:white" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">User Options <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo base_url()?>index.php/Form_Controller">Add New Sale</a></li>
                            <li><a href="<?php echo base_url()?>index.php/Pages_Controller/fetchAll">List All Sales</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                    <a href="#" style = "color:white"  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Hello, <?php echo $this->session->userdata('name');?> <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url(); ?>index.php/Logout_Controller/agent_logout">Logout</a></li>
                        <li><a href="<?php echo base_url();?>index.php/Pages_Controller/view_profile">View Profile</a></li>
                        <li><a href="<?php echo base_url();?>index.php/Pages_Controller/password_reset">Change Password</a></li>
                    </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>

	<div class="container" style = "margin-top: 100px">
            <div id="passwordreset" style="margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                
                <div class="alert alert-success" role="alert" id = "succ" hidden>
                    <strong>Well done!</strong> You successfully changed your password.
                </div>
                <div class="alert alert-danger" role="alert" id = "not_matched" hidden>
                    <strong>Sorry!</strong> Passwords didn't match, please try again.
                </div>
                <div class="alert alert-danger" role="alert" id = "small_pswrd" hidden>
                    <strong>Sorry!</strong> Password must contain 6 characters.
                </div>
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title">Create New Password</div>
                    </div>                     
                    <div class="panel-body">
                        <form id="signupform" class="form-horizontal" role="form" action = "<?php echo base_url()?>index.php/Pages_Controller/change_password" method = "post" onsubmit = "return validation()">
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>"/>
                            <div class="form-group">
                                <label for="email" class=" control-label col-sm-4">New password</label>
                                <div class="col-sm-8">
                                    <input type="password" id = "new_pswrd" class="form-control" name="password" placeholder="create your new password">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="email" class=" control-label col-sm-4">Confirm password</label>
                                <div class="col-sm-8">
                                    <input type="password" id = "cnfrm_pswrd" class="form-control" name="password_confirmation" placeholder="confirm your new password">
                                </div>
                            </div>
                        <div class="form-group">                               
                            <div class="  col-sm-offset-4 col-sm-8">
                                <button id="btn-signup" type="submit" class="btn btn-success">Submit</button>
                                <button id="btn-signup" type="reset" class="btn btn-info">Reset</button>
                            </div>
                        </div>                             
                    </form>
                </div>
            </div>
        </div>             
    </div>
</body>
<script type="text/javascript" src = "<?php echo base_url();?>assets/js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        <?php 
            if($this->session->flashdata('msg')){
        ?>
        $('#succ').show("slow");
        <?php
            }
        ?>
        setTimeout(function() { $("#succ").hide("slow"); }, 2000);
    });

    function validation(){
        var new_pswrd = $('#new_pswrd').val();
        var cnfrm_pswrd = $('#cnfrm_pswrd').val();
        
        var len = $('#new_pswrd').val().length;

        if(len<6){
            $('#small_pswrd').show("slow");
            setTimeout(function() { $("#small_pswrd").hide("slow"); }, 2000);
            return false;
        }

        if(new_pswrd != cnfrm_pswrd){
            $('#not_matched').show("slow");
            setTimeout(function() { $("#not_matched").hide("slow"); }, 2000);
            return false;
        }
    } 

    $('ul.nav li.dropdown').hover(function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeIn(500);
        }, function() {
            $(this).find('.dropdown-menu').stop(true, true).delay(200).fadeOut(500);
        });
</script>
</html>