$(document).ready(function(){
	$("#payment_selector").on("change", function(){
		var option = document.getElementById('payment_selector').value;
				
		if(option == 'Card')
			$("#card_payment_section").slideDown();
		else
			$("#card_payment_section").slideUp();
	});

    $('input[type=radio][name=domain_selector]').change(function() {
        if (this.value == 'New Domain') {
        	$('#existing_domain').hide();
         	$('#new_domain').show();
    	}
    	else if (this.value == 'Existing Domain') {
           	$('#new_domain').hide();
           	$('#existing_domain').show();
    	}
    });

    $('#keyword_selector').change(function() {
        if (this.value == 'NO')
            $('#reason').show();
        else
            $('#reason').hide();
    });

    $('input, textarea').keypress(function(){
        $('#success_message').hide();
        $('#failed_message').hide();
    });
});

function form_submission(){
    var cus_name = document.getElementById('cus_name').value;
    var bus_name = document.getElementById('bus_name').value;
    var bus_abn = document.getElementById('bus_abn').value;
    var email = document.getElementById('email').value;
    var p_type = document.getElementById('payment_selector').value;
            
    if(cus_name && bus_name && bus_abn && email && p_type){
        if(p_type == 'Card'){
            var card_name = document.getElementById('card_name').value;
            var card_num = document.getElementById('card_num').value;
            var card_exp = document.getElementById('card_exp').value;
            var card_cvv = document.getElementById('card_cvv').value;

        if(card_num && card_name && card_exp && card_cvv)
            return true;
        else{
            alert("Enter the card details");
            return false;
            }
        }
        return true;
    }
    else
        return false;
}